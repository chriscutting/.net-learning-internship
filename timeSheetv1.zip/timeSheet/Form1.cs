﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace timeSheet
{
    public partial class Form1 : Form
    {
        //Vars 
        //There are 92 of these, just as an fyi
        Double hour1;
        Double hour2;
        Double hour3;
        Double hour4;
        Double hour5;
        Double hour6;
        Double hour7;
        Double hour8;
        Double hour9;
        Double hour10;
        Double hour11;
        Double hour12;
        Double hour13;
        Double hour14;
        Double hour15;
        Double hour16;
        Double hour17;
        Double hour18;
        Double hour19;
        Double hour20;
        Double hour21;
        Double hour22;
        Double hour23;
        Double hour24;
        Double hour25;
        Double hour26;
        Double hour27;
        Double hour28;
        Double hour29;
        Double hour30;
        Double hour31;
        Double hour32;
        Double hour33;
        Double hour34;
        Double hour35;
        Double hour36;
        Double hour37;
        Double hour38;
        Double hour39;
        Double hour40;
        Double hour41;
        Double hour42;
        Double hour43;
        Double hour44;
        Double hour45;
        Double hour46;
        Double hour47;
        Double hour48;
        Double hour49;
        Double hour50;
        Double hour51;
        Double hour52;
        Double hour53;
        Double hour54;
        Double hour55;
        Double hour56;
        Double hour57;
        Double hour58;
        Double hour59;
        Double hour60;
        Double hour61;
        Double hour62;
        Double hour63;
        Double hour64;
        Double hour65;
        Double hour66;
        Double hour67;
        Double hour68;
        Double hour69;
        Double hour70;
        Double hour71;
        Double hour72;
        Double hour73;
        Double hour74;
        Double hour75;
        Double hour76;
        Double hour77;
        Double hour78;
        Double hour79;
        Double hour80;
        Double hour81;
        Double hour82;
        Double hour83;
        Double hour84;
        Double hour85;
        Double hour86;
        Double hour87;
        Double hour88;
        Double hour89;
        Double hour90;
        Double hour91;
        Double hour92;
        Double hour93;
        Double hour94;
        Double hour95;
        Double hour96;
        Double hour97;
        Double hour98;
        Double hour99;
        Double hour100;

        //Total Hour vars. There are 49. 

        Double totalHour1;
        Double totalHour2;
        Double totalHour3;
        Double totalHour4;
        Double totalHour5;
        Double totalHour6;
        Double totalHour7;
        Double totalHour8;
        Double totalHour9;
        Double totalHour10;
        Double totalHour11;
        Double totalHour12;
        Double totalHour13;
        Double totalHour14;
        Double totalHour15;
        Double totalHour16;
        Double totalHour17;
        Double totalHour18;
        Double totalHour19;
        Double totalHour20;
        Double totalHour21;
        Double totalHour22;
        Double totalHour23;
        Double totalHour24;
        Double totalHour25;
        Double totalHour26;
        Double totalHour27;
        Double totalHour28;
        Double totalHour29;
        Double totalHour30;
        Double totalHour31;
        Double totalHour32;
        Double totalHour33;
        Double totalHour34;
        Double totalHour35;
        Double totalHour36;
        Double totalHour37;
        Double totalHour38;
        Double totalHour39;
        Double totalHour40;
        Double totalHour41;
        Double totalHour42;
        Double totalHour43;
        Double totalHour44;
        Double totalHour45;
        Double totalHour46;
        Double totalHour47;
        Double totalHour48;
        Double totalHour49;
        Double totalHour50;


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Start time in/out as empty
            timeIn1.Enabled = false;
            timeIn2.Enabled = false;
            timeIn3.Enabled = false;
            timeIn4.Enabled = false;
            timeIn5.Enabled = false;
            timeIn6.Enabled = false;
            timeIn7.Enabled = false;
            timeIn8.Enabled = false;
            timeIn9.Enabled = false;
            timeIn10.Enabled = false;

            timeOut1.Enabled = false;
            timeOut2.Enabled = false;
            timeOut3.Enabled = false;
            timeOut4.Enabled = false;
            timeOut5.Enabled = false;
            timeOut6.Enabled = false;
            timeOut7.Enabled = false;
            timeOut8.Enabled = false;
            timeOut9.Enabled = false;
            timeOut10.Enabled = false;

            //Rates and OT(1)
            rate1.Items.Add("0");
            rate1.Items.Add("7.25");
            rate1.Items.Add("8.50");
            rate1.Items.Add("10");
            rate1.Items.Add("11.50");
            rate1.Items.Add("13");
            rate1.Items.Add("15");
            rate1.Items.Add("17.50");
            rate1.Items.Add("20");
            //rate(2)
            rate2.Items.Add("0");
            rate2.Items.Add("7.25");
            rate2.Items.Add("8.50");
            rate2.Items.Add("10");
            rate2.Items.Add("11.50");
            rate2.Items.Add("13");
            rate2.Items.Add("15");
            rate2.Items.Add("17.50");
            rate2.Items.Add("20");
            //rate(3)
            rate3.Items.Add("0");
            rate3.Items.Add("7.25");
            rate3.Items.Add("8.50");
            rate3.Items.Add("10");
            rate3.Items.Add("11.50");
            rate3.Items.Add("13");
            rate3.Items.Add("15");
            rate3.Items.Add("17.50");
            rate3.Items.Add("20");
            //rate(4)
            rate4.Items.Add("0");
            rate4.Items.Add("7.25");
            rate4.Items.Add("8.50");
            rate4.Items.Add("10");
            rate4.Items.Add("11.50");
            rate4.Items.Add("13");
            rate4.Items.Add("15");
            rate4.Items.Add("17.50");
            rate4.Items.Add("20");
            //rate(5)
            rate5.Items.Add("0");
            rate5.Items.Add("7.25");
            rate5.Items.Add("8.50");
            rate5.Items.Add("10");
            rate5.Items.Add("11.50");
            rate5.Items.Add("13");
            rate5.Items.Add("15");
            rate5.Items.Add("17.50");
            rate5.Items.Add("20");
            //rate(6)
            rate6.Items.Add("0");
            rate6.Items.Add("7.25");
            rate6.Items.Add("8.50");
            rate6.Items.Add("10");
            rate6.Items.Add("11.50");
            rate6.Items.Add("13");
            rate6.Items.Add("15");
            rate6.Items.Add("17.50");
            rate6.Items.Add("20");
            //rate(7)
            rate7.Items.Add("0");
            rate7.Items.Add("7.25");
            rate7.Items.Add("8.50");
            rate7.Items.Add("10");
            rate7.Items.Add("11.50");
            rate7.Items.Add("13");
            rate7.Items.Add("15");
            rate7.Items.Add("17.50");
            rate7.Items.Add("20");
            //rate(8)
            rate8.Items.Add("0");
            rate8.Items.Add("7.25");
            rate8.Items.Add("8.50");
            rate8.Items.Add("10");
            rate8.Items.Add("11.50");
            rate8.Items.Add("13");
            rate8.Items.Add("15");
            rate8.Items.Add("17.50");
            rate8.Items.Add("20");
            //rate(9)
            rate9.Items.Add("0");
            rate9.Items.Add("7.25");
            rate9.Items.Add("8.50");
            rate9.Items.Add("10");
            rate9.Items.Add("11.50");
            rate9.Items.Add("13");
            rate9.Items.Add("15");
            rate9.Items.Add("17.50");
            rate9.Items.Add("20");
            //rate(10)
            rate10.Items.Add("0");
            rate10.Items.Add("7.25");
            rate10.Items.Add("8.50");
            rate10.Items.Add("10");
            rate10.Items.Add("11.50");
            rate10.Items.Add("13");
            rate10.Items.Add("15");
            rate10.Items.Add("17.50");
            rate10.Items.Add("20");


            //-------------------------------------OT----------------------------------
            //OT1




            ot1.Items.Add("0");
            ot1.Items.Add("1");
            ot1.Items.Add("2");
            ot1.Items.Add("3");
            ot1.Items.Add("4");
            ot1.Items.Add("5");
            ot1.Items.Add("6");
            ot1.Items.Add("7");
            ot1.Items.Add("8");
            //OT2
            ot2.Items.Add("0");
            ot2.Items.Add("1");
            ot2.Items.Add("2");
            ot2.Items.Add("3");
            ot2.Items.Add("4");
            ot2.Items.Add("5");
            ot2.Items.Add("6");
            ot2.Items.Add("7");
            ot2.Items.Add("8");
            //OT3
            ot3.Items.Add("0");
            ot3.Items.Add("1");
            ot3.Items.Add("2");
            ot3.Items.Add("3");
            ot3.Items.Add("4");
            ot3.Items.Add("5");
            ot3.Items.Add("6");
            ot3.Items.Add("7");
            ot3.Items.Add("8");
            //OT4
            ot4.Items.Add("0");
            ot4.Items.Add("1");
            ot4.Items.Add("2");
            ot4.Items.Add("3");
            ot4.Items.Add("4");
            ot4.Items.Add("5");
            ot4.Items.Add("6");
            ot4.Items.Add("7");
            ot4.Items.Add("8");
            //OT5
            ot5.Items.Add("0");
            ot5.Items.Add("1");
            ot5.Items.Add("2");
            ot5.Items.Add("3");
            ot5.Items.Add("4");
            ot5.Items.Add("5");
            ot5.Items.Add("6");
            ot5.Items.Add("7");
            ot5.Items.Add("8");
            //OT6
            ot6.Items.Add("0");
            ot6.Items.Add("1");
            ot6.Items.Add("2");
            ot6.Items.Add("3");
            ot6.Items.Add("4");
            ot6.Items.Add("5");
            ot6.Items.Add("6");
            ot6.Items.Add("7");
            ot6.Items.Add("8");
            //OT7
            ot7.Items.Add("0");
            ot7.Items.Add("1");
            ot7.Items.Add("2");
            ot7.Items.Add("3");
            ot7.Items.Add("4");
            ot7.Items.Add("5");
            ot7.Items.Add("6");
            ot7.Items.Add("7");
            ot7.Items.Add("8");
            //OT8
            ot8.Items.Add("0");
            ot8.Items.Add("1");
            ot8.Items.Add("2");
            ot8.Items.Add("3");
            ot8.Items.Add("4");
            ot8.Items.Add("5");
            ot8.Items.Add("6");
            ot8.Items.Add("7");
            ot8.Items.Add("8");
            //OT9
            ot9.Items.Add("0");
            ot9.Items.Add("1");
            ot9.Items.Add("2");
            ot9.Items.Add("3");
            ot9.Items.Add("4");
            ot9.Items.Add("5");
            ot9.Items.Add("6");
            ot9.Items.Add("7");
            ot9.Items.Add("8");
            //OT10
            ot10.Items.Add("0");
            ot10.Items.Add("1");
            ot10.Items.Add("2");
            ot10.Items.Add("3");
            ot10.Items.Add("4");
            ot10.Items.Add("5");
            ot10.Items.Add("6");
            ot10.Items.Add("7");
            ot10.Items.Add("8");
        }

        
           

        
        //-------------------------Radio button functions----------------------------
        private void radMon_CheckedChanged(object sender, EventArgs e)
        {
            timeIn1.Enabled = true;
            timeIn2.Enabled = true;
            timeIn3.Enabled = true;
            timeIn4.Enabled = true;
            timeIn5.Enabled = true;
            timeIn6.Enabled = true;
            timeIn7.Enabled = true;
            timeIn8.Enabled = true;
            timeIn9.Enabled = true;
            timeIn10.Enabled = true;

            timeOut1.Enabled = true;
            timeOut2.Enabled = true;
            timeOut3.Enabled = true;
            timeOut4.Enabled = true;
            timeOut5.Enabled = true;
            timeOut6.Enabled = true;
            timeOut7.Enabled = true;
            timeOut8.Enabled = true;
            timeOut9.Enabled = true;
            timeOut10.Enabled = true;



        }
        private void radTues_CheckedChanged(object sender, EventArgs e)
        {
            timeIn1.Enabled = true;
            timeIn2.Enabled = true;
            timeIn3.Enabled = true;
            timeIn4.Enabled = true;
            timeIn5.Enabled = true;
            timeIn6.Enabled = true;
            timeIn7.Enabled = true;
            timeIn8.Enabled = true;
            timeIn9.Enabled = true;
            timeIn10.Enabled = true;

            timeOut1.Enabled = true;
            timeOut2.Enabled = true;
            timeOut3.Enabled = true;
            timeOut4.Enabled = true;
            timeOut5.Enabled = true;
            timeOut6.Enabled = true;
            timeOut7.Enabled = true;
            timeOut8.Enabled = true;
            timeOut9.Enabled = true;
            timeOut10.Enabled = true;
        }
        private void radWed_CheckedChanged(object sender, EventArgs e)
        {
            timeIn1.Enabled = true;
            timeIn2.Enabled = true;
            timeIn3.Enabled = true;
            timeIn4.Enabled = true;
            timeIn5.Enabled = true;
            timeIn6.Enabled = true;
            timeIn7.Enabled = true;
            timeIn8.Enabled = true;
            timeIn9.Enabled = true;
            timeIn10.Enabled = true;

            timeOut1.Enabled = true;
            timeOut2.Enabled = true;
            timeOut3.Enabled = true;
            timeOut4.Enabled = true;
            timeOut5.Enabled = true;
            timeOut6.Enabled = true;
            timeOut7.Enabled = true;
            timeOut8.Enabled = true;
            timeOut9.Enabled = true;
            timeOut10.Enabled = true;
        }
        private void radThurs_CheckedChanged(object sender, EventArgs e)
        {
            timeIn1.Enabled = true;
            timeIn2.Enabled = true;
            timeIn3.Enabled = true;
            timeIn4.Enabled = true;
            timeIn5.Enabled = true;
            timeIn6.Enabled = true;
            timeIn7.Enabled = true;
            timeIn8.Enabled = true;
            timeIn9.Enabled = true;
            timeIn10.Enabled = true;

            timeOut1.Enabled = true;
            timeOut2.Enabled = true;
            timeOut3.Enabled = true;
            timeOut4.Enabled = true;
            timeOut5.Enabled = true;
            timeOut6.Enabled = true;
            timeOut7.Enabled = true;
            timeOut8.Enabled = true;
            timeOut9.Enabled = true;
            timeOut10.Enabled = true;
        }
        private void radFri_CheckedChanged(object sender, EventArgs e)
        {
            timeIn1.Enabled = true;
            timeIn2.Enabled = true;
            timeIn3.Enabled = true;
            timeIn4.Enabled = true;
            timeIn5.Enabled = true;
            timeIn6.Enabled = true;
            timeIn7.Enabled = true;
            timeIn8.Enabled = true;
            timeIn9.Enabled = true;
            timeIn10.Enabled = true;

            timeOut1.Enabled = true;
            timeOut2.Enabled = true;
            timeOut3.Enabled = true;
            timeOut4.Enabled = true;
            timeOut5.Enabled = true;
            timeOut6.Enabled = true;
            timeOut7.Enabled = true;
            timeOut8.Enabled = true;
            timeOut9.Enabled = true;
            timeOut10.Enabled = true;
        }

        private void rate1_SelectedIndexChanged(object sender, EventArgs e)
        {
            rate1.Items.Add("0");
        }

        //Total wage button/calcs------------------------------------------------------------------------------------------

        
         
        

        private void totalWageButton_Click(object sender, EventArgs e)
        { String replace;
            Double m;
            //---------------------------------Calc for all Mon Entries-------------------------------------------------
            if (radMon.Checked == true)

            {
                hour2 = Convert.ToDouble(timeIn1.Text);
                hour1 = Convert.ToDouble(timeOut1.Text);
                totalHour1 = hour1 - hour2;
                hoursLabel1.Text = Convert.ToString(totalHour1 / 24);
                hoursLabel1.Text = Convert.ToString(totalHour1);
                lblMon1.Text = Convert.ToString(Math.Round(totalHour1 * Convert.ToDouble(rate1.Text)) + Math.Round(Convert.ToDouble(rate1.Text) * Convert.ToDouble(ot1.Text)));
                lblMon1.Text = "$ " + lblMon1.Text;

                totalPymt1.Text = lblMon1.Text;

                hour4 = Convert.ToDouble(timeIn2.Text);
                hour3 = Convert.ToDouble(timeOut2.Text);
                totalHour2 = hour3 - hour4;
                hoursLabel2.Text = Convert.ToString(totalHour2 / 24);
                hoursLabel2.Text = Convert.ToString(totalHour2);
                lblMon2.Text = Convert.ToString(Math.Round(totalHour2 * Convert.ToDouble(rate2.Text)) + Math.Round(Convert.ToDouble(rate2.Text) * Convert.ToDouble(ot2.Text)));
                lblMon2.Text = "$ " + lblMon2.Text;
                totalPymt2.Text = lblMon2.Text;

                hour6 = Convert.ToDouble(timeIn3.Text);
                hour5 = Convert.ToDouble(timeOut3.Text);
                totalHour3 = hour5 - hour6;
                hoursLabel3.Text = Convert.ToString(totalHour3 / 24);
                hoursLabel3.Text = Convert.ToString(totalHour3);
                lblMon3.Text = Convert.ToString(Math.Round(totalHour3 * Convert.ToDouble(rate3.Text)) + Math.Round(Convert.ToDouble(rate3.Text) * Convert.ToDouble(ot3.Text)));
                lblMon3.Text = "$ " + lblMon3.Text;
                totalPymt3.Text = lblMon3.Text;

                hour8 = Convert.ToDouble(timeIn4.Text);
                hour7 = Convert.ToDouble(timeOut4.Text);
                totalHour4 = hour7 - hour8;
                hoursLabel4.Text = Convert.ToString(totalHour4 / 24);
                hoursLabel4.Text = Convert.ToString(totalHour4);
                lblMon4.Text = Convert.ToString(Math.Round(totalHour4 * Convert.ToDouble(rate4.Text)) + Math.Round(Convert.ToDouble(rate4.Text) * Convert.ToDouble(ot4.Text)));
                lblMon4.Text = "$ " + lblMon4.Text;
                totalPymt4.Text = lblMon4.Text;

                hour10 = Convert.ToDouble(timeIn5.Text);
                hour9 = Convert.ToDouble(timeOut5.Text);
                totalHour5 = hour9 - hour10;
                hoursLabel5.Text = Convert.ToString(totalHour5 / 24);
                hoursLabel5.Text = Convert.ToString(totalHour5);
                lblMon5.Text = Convert.ToString(Math.Round(totalHour5 * Convert.ToDouble(rate5.Text)) + Math.Round(Convert.ToDouble(rate5.Text) * Convert.ToDouble(ot5.Text)));
                lblMon5.Text = "$ " + lblMon5.Text;
                totalPymt5.Text = lblMon5.Text;

                hour12 = Convert.ToDouble(timeIn6.Text);
                hour11 = Convert.ToDouble(timeOut6.Text);
                totalHour6 = hour11 - hour12;
                hoursLabel6.Text = Convert.ToString(totalHour6 / 24);
                hoursLabel6.Text = Convert.ToString(totalHour6);
                lblMon6.Text = Convert.ToString(Math.Round(totalHour6 * Convert.ToDouble(rate6.Text)) + Math.Round(Convert.ToDouble(rate6.Text) * Convert.ToDouble(ot6.Text)));
                lblMon6.Text = "$ " + lblMon6.Text;
                totalPymt6.Text = lblMon6.Text;

                hour14 = Convert.ToDouble(timeIn7.Text);
                hour13 = Convert.ToDouble(timeOut7.Text);
                totalHour7 = hour13 - hour14;
                hoursLabel7.Text = Convert.ToString(totalHour7 / 24);
                hoursLabel7.Text = Convert.ToString(totalHour7);
                lblMon7.Text = Convert.ToString(Math.Round(totalHour7 * Convert.ToDouble(rate7.Text)) + Math.Round(Convert.ToDouble(rate7.Text) * Convert.ToDouble(ot7.Text)));
                lblMon7.Text = "$ " + lblMon7.Text;
                totalPymt7.Text = lblMon7.Text;

                hour16 = Convert.ToDouble(timeIn8.Text);
                hour15 = Convert.ToDouble(timeOut8.Text);
                totalHour8 = hour15 - hour16;
                hoursLabel8.Text = Convert.ToString(totalHour8 / 24);
                hoursLabel8.Text = Convert.ToString(totalHour8);
                lblMon8.Text = Convert.ToString(Math.Round(totalHour8 * Convert.ToDouble(rate8.Text)) + Math.Round(Convert.ToDouble(rate8.Text) * Convert.ToDouble(ot8.Text)));
                lblMon8.Text = "$ " + lblMon8.Text;
                totalPymt8.Text = lblMon8.Text;

                hour18 = Convert.ToDouble(timeIn9.Text);
                hour17 = Convert.ToDouble(timeOut9.Text);
                totalHour9 = hour17 - hour18;
                hoursLabel9.Text = Convert.ToString(totalHour9 / 24);
                hoursLabel9.Text = Convert.ToString(totalHour9);
                lblMon9.Text = Convert.ToString(Math.Round(totalHour9 * Convert.ToDouble(rate9.Text)) + Math.Round(Convert.ToDouble(rate9.Text) * Convert.ToDouble(ot9.Text)));
                lblMon9.Text = "$ " + lblMon9.Text;
                totalPymt9.Text = lblMon9.Text;

                hour20 = Convert.ToDouble(timeIn10.Text);
                hour19 = Convert.ToDouble(timeOut10.Text);
                totalHour10 = hour19 - hour20;
                hoursLabel10.Text = Convert.ToString(totalHour10 / 24);
                hoursLabel10.Text = Convert.ToString(totalHour10);
                lblMon10.Text = Convert.ToString(Math.Round(totalHour10 * Convert.ToDouble(rate10.Text)) + Math.Round(Convert.ToDouble(rate10.Text) * Convert.ToDouble(ot10.Text)));
                lblMon10.Text = "$ " + lblMon10.Text;
                totalPymt10.Text = lblMon10.Text;

                //---------------------------------Calc for all Tues Entries-------------------------------------------------



            }
            else if (radTues.Checked == true)
            {

                replace = Convert.ToString(totalPymt1.Text);
                
                totalPymt1.Text = "";
                hour22 = Convert.ToDouble(timeIn1.Text);
                hour21 = Convert.ToDouble(timeOut1.Text);
                totalHour11 = hour21 - hour22;
                hoursLabel1.Text = Convert.ToString(totalHour11 / 24);
                hoursLabel1.Text = Convert.ToString(totalHour11);
                lblTues1.Text = Convert.ToString(Math.Round(totalHour11 * Convert.ToDouble(rate1.Text)) + Math.Round(Convert.ToDouble(rate1.Text) * Convert.ToDouble(ot1.Text)));
                lblTues1.Text = "$ " + lblTues1.Text;
                
                totalPymt1.Text = lblTues1.Text;
                totalPymt1.Text = lblTues1.Text + m;

                m = Convert.ToDouble(totalPymt2.Text);
                totalPymt2.Text = "";
                hour24 = Convert.ToDouble(timeIn2.Text);
                hour23 = Convert.ToDouble(timeOut2.Text);
                totalHour12 = hour23 - hour24;
                hoursLabel2.Text = Convert.ToString(totalHour12 / 24);
                hoursLabel2.Text = Convert.ToString(totalHour12);
                lblTues2.Text = Convert.ToString(Math.Round(totalHour12 * Convert.ToDouble(rate2.Text)) + Math.Round(Convert.ToDouble(rate2.Text) * Convert.ToDouble(ot2.Text)));
                lblTues2.Text = "$ " + lblTues2.Text;
                totalPymt2.Text = lblTues2.Text;
                totalPymt2.Text = lblTues2.Text + m;

                m = Convert.ToDouble(totalPymt3.Text);
                totalPymt3.Text = "";
                hour26 = Convert.ToDouble(timeIn3.Text);
                hour25 = Convert.ToDouble(timeOut3.Text);
                totalHour13 = hour25 - hour26;
                hoursLabel3.Text = Convert.ToString(totalHour13 / 24);
                hoursLabel3.Text = Convert.ToString(totalHour13);
                lblTues3.Text = Convert.ToString(Math.Round(totalHour13 * Convert.ToDouble(rate3.Text)) + Math.Round(Convert.ToDouble(rate3.Text) * Convert.ToDouble(ot3.Text)));
                lblTues3.Text = "$ " + lblTues3.Text;
                totalPymt3.Text = lblTues3.Text;
                totalPymt3.Text = lblTues3.Text + m;

                m = Convert.ToDouble(totalPymt4.Text);
                totalPymt4.Text = "";
                hour28 = Convert.ToDouble(timeIn4.Text);
                hour27 = Convert.ToDouble(timeOut4.Text);
                totalHour14 = hour27 - hour28;
                hoursLabel4.Text = Convert.ToString(totalHour14 / 24);
                hoursLabel4.Text = Convert.ToString(totalHour14);
                lblTues4.Text = Convert.ToString(Math.Round(totalHour14 * Convert.ToDouble(rate4.Text)) + Math.Round(Convert.ToDouble(rate4.Text) * Convert.ToDouble(ot4.Text)));
                lblTues4.Text = "$ " + lblTues4.Text;
                totalPymt4.Text = lblTues4.Text;
                totalPymt4.Text = lblTues4.Text + m;

                m = Convert.ToDouble(totalPymt5.Text);
                totalPymt5.Text = "";
                hour30 = Convert.ToDouble(timeIn5.Text);
                hour29 = Convert.ToDouble(timeOut5.Text);
                totalHour15 = hour29 - hour30;
                hoursLabel5.Text = Convert.ToString(totalHour15 / 24);
                hoursLabel5.Text = Convert.ToString(totalHour15);
                lblTues5.Text = Convert.ToString(Math.Round(totalHour15 * Convert.ToDouble(rate5.Text)) + Math.Round(Convert.ToDouble(rate5.Text) * Convert.ToDouble(ot5.Text)));
                lblTues5.Text = "$ " + lblTues5.Text;
                totalPymt5.Text = lblTues5.Text;
                totalPymt5.Text = lblTues5.Text + m;

                m = Convert.ToDouble(totalPymt6.Text);
                totalPymt6.Text = "";
                hour32 = Convert.ToDouble(timeIn6.Text);
                hour31 = Convert.ToDouble(timeOut6.Text);
                totalHour16 = hour31 - hour32;
                hoursLabel6.Text = Convert.ToString(totalHour16 / 24);
                hoursLabel6.Text = Convert.ToString(totalHour16);
                lblTues6.Text = Convert.ToString(Math.Round(totalHour16 * Convert.ToDouble(rate6.Text)) + Math.Round(Convert.ToDouble(rate6.Text) * Convert.ToDouble(ot6.Text)));
                lblTues6.Text = "$ " + lblTues6.Text;
                totalPymt6.Text = lblTues6.Text;
                totalPymt6.Text = lblTues6.Text + m;

                m = Convert.ToDouble(totalPymt7.Text);
                totalPymt7.Text = "";
                hour34 = Convert.ToDouble(timeIn7.Text);
                hour33 = Convert.ToDouble(timeOut7.Text);
                totalHour17 = hour33 - hour34;
                hoursLabel7.Text = Convert.ToString(totalHour17 / 24);
                hoursLabel7.Text = Convert.ToString(totalHour17);
                lblTues7.Text = Convert.ToString(Math.Round(totalHour17 * Convert.ToDouble(rate7.Text)) + Math.Round(Convert.ToDouble(rate7.Text) * Convert.ToDouble(ot7.Text)));
                lblTues7.Text = "$ " + lblTues7.Text;
                totalPymt7.Text = lblTues7.Text;
                totalPymt7.Text = lblTues7.Text + m;

                m = Convert.ToDouble(totalPymt8.Text);
                totalPymt8.Text = "";
                hour36 = Convert.ToDouble(timeIn8.Text);
                hour35 = Convert.ToDouble(timeOut8.Text);
                totalHour18 = hour35 - hour36;
                hoursLabel8.Text = Convert.ToString(totalHour18 / 24);
                hoursLabel8.Text = Convert.ToString(totalHour18);
                lblTues8.Text = Convert.ToString(Math.Round(totalHour18 * Convert.ToDouble(rate8.Text)) + Math.Round(Convert.ToDouble(rate8.Text) * Convert.ToDouble(ot8.Text)));
                lblTues8.Text = "$ " + lblTues8.Text;
                totalPymt8.Text = lblTues8.Text;
                totalPymt8.Text = lblTues8.Text + m;

                m = Convert.ToDouble(totalPymt9.Text);
                totalPymt9.Text = "";
                hour38 = Convert.ToDouble(timeIn9.Text);
                hour37 = Convert.ToDouble(timeOut9.Text);
                totalHour19 = hour37 - hour38;
                hoursLabel9.Text = Convert.ToString(totalHour19 / 24);
                hoursLabel9.Text = Convert.ToString(totalHour19);
                lblTues9.Text = Convert.ToString(Math.Round(totalHour19 * Convert.ToDouble(rate9.Text)) + Math.Round(Convert.ToDouble(rate9.Text) * Convert.ToDouble(ot9.Text)));
  
                totalPymt9.Text = lblTues9.Text;
                totalPymt9.Text = lblTues9.Text + m;

                m = Convert.ToDouble(totalPymt10.Text);
                totalPymt10.Text = "";
                hour40 = Convert.ToDouble(timeIn10.Text);
                hour39 = Convert.ToDouble(timeOut10.Text);
                totalHour20 = hour39 - hour40;
                hoursLabel10.Text = Convert.ToString(totalHour20 / 24);
                hoursLabel10.Text = Convert.ToString(totalHour20);
                lblTues10.Text = Convert.ToString(Math.Round(totalHour20 * Convert.ToDouble(rate10.Text)) + Math.Round(Convert.ToDouble(rate10.Text) * Convert.ToDouble(ot10.Text)));
                
                totalPymt10.Text = lblTues10.Text;
                totalPymt10.Text = lblTues10.Text + m;
                
                //---------------------------------Calc for all Weds Entries-------------------------------------------------
                 



            }
            else if (radWed.Checked == true)
            {
                m = Convert.ToDouble(totalPymt1.Text);
                totalPymt1.Text = "";
                hour42 = Convert.ToDouble(timeIn1.Text);
                hour41 = Convert.ToDouble(timeOut1.Text);
                totalHour21 = hour41 - hour42;
                hoursLabel1.Text = Convert.ToString(totalHour21 / 24);
                hoursLabel1.Text = Convert.ToString(totalHour21);
                lblWed1.Text = Convert.ToString(Math.Round(totalHour21 * Convert.ToDouble(rate1.Text)) + Math.Round(Convert.ToDouble(rate1.Text) * Convert.ToDouble(ot1.Text)));
                
                totalPymt1.Text = lblWed1.Text;
                totalPymt1.Text = lblWed1.Text + m;

                m = Convert.ToDouble(totalPymt2.Text);
                totalPymt2.Text = "";
                hour44 = Convert.ToDouble(timeIn2.Text);
                hour43 = Convert.ToDouble(timeOut2.Text);
                totalHour22 = hour43 - hour44;
                hoursLabel2.Text = Convert.ToString(totalHour22 / 24);
                hoursLabel2.Text = Convert.ToString(totalHour22);
                lblWed2.Text = Convert.ToString(Math.Round(totalHour22 * Convert.ToDouble(rate2.Text)) + Math.Round(Convert.ToDouble(rate2.Text) * Convert.ToDouble(ot2.Text)));
                lblWed2.Text = "$ " + lblWed2.Text;
                totalPymt2.Text = lblWed2.Text;
                totalPymt2.Text = lblWed2.Text + m;

                m = Convert.ToDouble(totalPymt3.Text);
                totalPymt3.Text = "";
                hour46 = Convert.ToDouble(timeIn3.Text);
                hour45 = Convert.ToDouble(timeOut3.Text);
                totalHour23 = hour45 - hour46;
                hoursLabel3.Text = Convert.ToString(totalHour23 / 24);
                hoursLabel3.Text = Convert.ToString(totalHour23);
                lblWed3.Text = Convert.ToString(Math.Round(totalHour22 * Convert.ToDouble(rate3.Text)) + Math.Round(Convert.ToDouble(rate3.Text) * Convert.ToDouble(ot3.Text)));
                lblWed3.Text = "$ " + lblWed3.Text;
                totalPymt3.Text = lblWed3.Text;
                totalPymt3.Text = lblWed3.Text + m;

                m = Convert.ToDouble(totalPymt4.Text);
                totalPymt4.Text = "";
                hour48 = Convert.ToDouble(timeIn4.Text);
                hour47 = Convert.ToDouble(timeOut4.Text);
                totalHour24 = hour47 - hour48;
                hoursLabel4.Text = Convert.ToString(totalHour24 / 24);
                hoursLabel4.Text = Convert.ToString(totalHour24);
                lblWed4.Text = Convert.ToString(Math.Round(totalHour24 * Convert.ToDouble(rate4.Text)) + Math.Round(Convert.ToDouble(rate4.Text) * Convert.ToDouble(ot4.Text)));
                lblWed4.Text = "$ " + lblWed4.Text;
                totalPymt4.Text = lblWed4.Text;
                totalPymt4.Text = lblWed4.Text + m;

                m = Convert.ToDouble(totalPymt5.Text);
                totalPymt5.Text = "";
                hour50 = Convert.ToDouble(timeIn5.Text);
                hour49 = Convert.ToDouble(timeOut5.Text);
                totalHour25 = hour49 - hour50;
                hoursLabel5.Text = Convert.ToString(totalHour25 / 24);
                hoursLabel5.Text = Convert.ToString(totalHour25);
                lblWed5.Text = Convert.ToString(Math.Round(totalHour25 * Convert.ToDouble(rate5.Text)) + Math.Round(Convert.ToDouble(rate5.Text) * Convert.ToDouble(ot5.Text)));
                lblWed5.Text = "$ " + lblWed5.Text;
                totalPymt5.Text = lblWed5.Text;
                totalPymt5.Text = lblWed5.Text + m;

                m = Convert.ToDouble(totalPymt6.Text);
                totalPymt6.Text = "";
                hour52 = Convert.ToDouble(timeIn6.Text);
                hour51 = Convert.ToDouble(timeOut6.Text);
                totalHour26 = hour51 - hour52;
                hoursLabel6.Text = Convert.ToString(totalHour26 / 24);
                hoursLabel6.Text = Convert.ToString(totalHour26);
                lblWed6.Text = Convert.ToString(Math.Round(totalHour26 * Convert.ToDouble(rate6.Text)) + Math.Round(Convert.ToDouble(rate6.Text) * Convert.ToDouble(ot6.Text)));
                lblWed6.Text = "$ " + lblWed6.Text;
                totalPymt6.Text = lblWed6.Text;
                totalPymt6.Text = lblWed6.Text + m;

                m = Convert.ToDouble(totalPymt7.Text);
                totalPymt7.Text = "";
                hour54 = Convert.ToDouble(timeIn7.Text);
                hour53 = Convert.ToDouble(timeOut7.Text);
                totalHour27 = hour53 - hour54;
                hoursLabel7.Text = Convert.ToString(totalHour27 / 24);
                hoursLabel7.Text = Convert.ToString(totalHour27);
                lblWed7.Text = Convert.ToString(Math.Round(totalHour27 * Convert.ToDouble(rate7.Text)) + Math.Round(Convert.ToDouble(rate7.Text) * Convert.ToDouble(ot7.Text)));
                lblWed7.Text = "$ " + lblWed7.Text;
                totalPymt7.Text = lblWed7.Text;
                totalPymt7.Text = lblWed7.Text + m;

                m = Convert.ToDouble(totalPymt8.Text);
                totalPymt8.Text = "";
                hour56 = Convert.ToDouble(timeIn8.Text);
                hour55 = Convert.ToDouble(timeOut8.Text);
                totalHour28 = hour55 - hour56;
                hoursLabel8.Text = Convert.ToString(totalHour28 / 24);
                hoursLabel8.Text = Convert.ToString(totalHour28);
                lblWed8.Text = Convert.ToString(Math.Round(totalHour28 * Convert.ToDouble(rate8.Text)) + Math.Round(Convert.ToDouble(rate8.Text) * Convert.ToDouble(ot8.Text)));
                lblWed8.Text = "$ " + lblWed8.Text;
                totalPymt8.Text = lblWed8.Text;
                totalPymt8.Text = lblWed8.Text + m;

                m = Convert.ToDouble(totalPymt9.Text);
                totalPymt9.Text = "";
                hour58 = Convert.ToDouble(timeIn9.Text);
                hour57 = Convert.ToDouble(timeOut9.Text);
                totalHour29 = hour57 - hour58;
                hoursLabel9.Text = Convert.ToString(totalHour29 / 24);
                hoursLabel9.Text = Convert.ToString(totalHour29);
                lblWed9.Text = Convert.ToString(Math.Round(totalHour29 * Convert.ToDouble(rate9.Text)) + Math.Round(Convert.ToDouble(rate9.Text) * Convert.ToDouble(ot9.Text)));
                lblWed9.Text = "$ " + lblWed9.Text;
                totalPymt9.Text = lblWed9.Text;
                totalPymt9.Text = lblWed9.Text + m;

                m = Convert.ToDouble(totalPymt10.Text);
                totalPymt10.Text = "";
                hour60 = Convert.ToDouble(timeIn10.Text);
                hour59 = Convert.ToDouble(timeOut10.Text);
                totalHour30 = hour59 - hour60;
                hoursLabel10.Text = Convert.ToString(totalHour30 / 24);
                hoursLabel10.Text = Convert.ToString(totalHour30);
                lblWed10.Text = Convert.ToString(Math.Round(totalHour30 * Convert.ToDouble(rate10.Text)) + Math.Round(Convert.ToDouble(rate10.Text) * Convert.ToDouble(ot10.Text)));
                lblWed10.Text = "$ " + lblWed10.Text;
                totalPymt10.Text = lblWed10.Text;
                totalPymt10.Text = lblWed10.Text + m;

            }
            else if(radThurs.Checked == true)
            {
                //---------------------------------Calc for all Thurs Entries-------------------------------------------------
                m = Convert.ToDouble(totalPymt1.Text);
                totalPymt1.Text = "";
                hour62 = Convert.ToDouble(timeIn1.Text);
                hour61 = Convert.ToDouble(timeOut1.Text);
                totalHour31 = hour61 - hour62;
                hoursLabel1.Text = Convert.ToString(totalHour31 / 24);
                hoursLabel1.Text = Convert.ToString(totalHour31);
                lblThurs1.Text = Convert.ToString(Math.Round(totalHour31 * Convert.ToDouble(rate1.Text)) + Math.Round(Convert.ToDouble(rate1.Text) * Convert.ToDouble(ot1.Text)));
                lblThurs1.Text = "$ " + lblThurs1.Text;
                totalPymt1.Text = lblThurs1.Text;
                totalPymt1.Text = lblThurs1.Text + m;

                m = Convert.ToDouble(totalPymt2.Text);
                totalPymt2.Text = "";
                hour64 = Convert.ToDouble(timeIn2.Text);
                hour63 = Convert.ToDouble(timeOut2.Text);
                totalHour32 = hour63 - hour64;
                hoursLabel2.Text = Convert.ToString(totalHour32 / 24);
                hoursLabel2.Text = Convert.ToString(totalHour32);
                lblThurs2.Text = Convert.ToString(Math.Round(totalHour32 * Convert.ToDouble(rate2.Text)) + Math.Round(Convert.ToDouble(rate2.Text) * Convert.ToDouble(ot2.Text)));
                lblThurs2.Text = "$ " + lblThurs2.Text;
                totalPymt2.Text = lblThurs2.Text;
                totalPymt2.Text = lblThurs2.Text + m;

                m = Convert.ToDouble(totalPymt3.Text);
                totalPymt3.Text = "";
                hour66 = Convert.ToDouble(timeIn3.Text);
                hour65 = Convert.ToDouble(timeOut3.Text);
                totalHour33 = hour65 - hour66;
                hoursLabel3.Text = Convert.ToString(totalHour33 / 24);
                hoursLabel3.Text = Convert.ToString(totalHour33);
                lblThurs3.Text = Convert.ToString(Math.Round(totalHour33 * Convert.ToDouble(rate3.Text)) + Math.Round(Convert.ToDouble(rate3.Text) * Convert.ToDouble(ot3.Text)));
                lblThurs3.Text = "$ " + lblThurs3.Text;
                totalPymt3.Text = lblThurs3.Text;
                totalPymt3.Text = lblThurs3.Text + m;

                m = Convert.ToDouble(totalPymt4.Text);
                totalPymt4.Text = "";
                hour68 = Convert.ToDouble(timeIn4.Text);
                hour67 = Convert.ToDouble(timeOut4.Text);
                totalHour34 = hour67 - hour68;
                hoursLabel4.Text = Convert.ToString(totalHour34 / 24);
                hoursLabel4.Text = Convert.ToString(totalHour34);
                lblThurs4.Text = Convert.ToString(Math.Round(totalHour34 * Convert.ToDouble(rate4.Text)) + Math.Round(Convert.ToDouble(rate4.Text) * Convert.ToDouble(ot4.Text)));
                lblThurs4.Text = "$ " + lblThurs4.Text;
                totalPymt4.Text = lblThurs4.Text;
                totalPymt4.Text = lblThurs4.Text + m;

                m = Convert.ToDouble(totalPymt5.Text);
                totalPymt5.Text = "";
                hour70 = Convert.ToDouble(timeIn5.Text);
                hour69 = Convert.ToDouble(timeOut5.Text);
                totalHour35 = hour69 - hour70;
                hoursLabel5.Text = Convert.ToString(totalHour35 / 24);
                hoursLabel5.Text = Convert.ToString(totalHour35);
                lblThurs5.Text = Convert.ToString(Math.Round(totalHour35 * Convert.ToDouble(rate5.Text)) + Math.Round(Convert.ToDouble(rate5.Text) * Convert.ToDouble(ot5.Text)));
                lblThurs5.Text = "$ " + lblThurs5.Text;
                totalPymt5.Text = lblThurs5.Text;
                totalPymt5.Text = lblThurs5.Text + m;

                m = Convert.ToDouble(totalPymt6.Text);
                totalPymt6.Text = "";
                hour72 = Convert.ToDouble(timeIn6.Text);
                hour71 = Convert.ToDouble(timeOut6.Text);
                totalHour36 = hour71 - hour72;
                hoursLabel6.Text = Convert.ToString(totalHour36 / 24);
                hoursLabel6.Text = Convert.ToString(totalHour36);
                lblThurs6.Text = Convert.ToString(Math.Round(totalHour36 * Convert.ToDouble(rate6.Text)) + Math.Round(Convert.ToDouble(rate6.Text) * Convert.ToDouble(ot6.Text)));
                lblThurs6.Text = "$ " + lblThurs5.Text;
                totalPymt6.Text = lblThurs6.Text;
                totalPymt6.Text = lblThurs6.Text + m;

                m = Convert.ToDouble(totalPymt7.Text);
                totalPymt7.Text = "";
                hour74 = Convert.ToDouble(timeIn7.Text);
                hour73 = Convert.ToDouble(timeOut7.Text);
                totalHour37 = hour73 - hour74;
                hoursLabel7.Text = Convert.ToString(totalHour37 / 24);
                hoursLabel7.Text = Convert.ToString(totalHour37);
                lblThurs7.Text = Convert.ToString(Math.Round(totalHour37 * Convert.ToDouble(rate7.Text)) + Math.Round(Convert.ToDouble(rate7.Text) * Convert.ToDouble(ot7.Text)));
                lblThurs7.Text = "$ " + lblThurs7.Text;
                totalPymt7.Text = lblThurs7.Text;
                totalPymt7.Text = lblThurs7.Text + m;

                m = Convert.ToDouble(totalPymt8.Text);
                totalPymt8.Text = "";
                hour76 = Convert.ToDouble(timeIn8.Text);
                hour75 = Convert.ToDouble(timeOut8.Text);
                totalHour38 = hour75 - hour76;
                hoursLabel8.Text = Convert.ToString(totalHour38 / 24);
                hoursLabel8.Text = Convert.ToString(totalHour38);
                lblThurs8.Text = Convert.ToString(Math.Round(totalHour38 * Convert.ToDouble(rate8.Text)) + Math.Round(Convert.ToDouble(rate8.Text) * Convert.ToDouble(ot8.Text)));
                lblThurs8.Text = "$ " + lblThurs8.Text;
                totalPymt8.Text = lblThurs8.Text;
                totalPymt8.Text = lblThurs8.Text + m;

                m = Convert.ToDouble(totalPymt9.Text);
                totalPymt9.Text = "";
                hour78 = Convert.ToDouble(timeIn9.Text);
                hour77 = Convert.ToDouble(timeOut9.Text);
                totalHour39 = hour77 - hour78;
                hoursLabel9.Text = Convert.ToString(totalHour39 / 24);
                hoursLabel9.Text = Convert.ToString(totalHour39);
                lblThurs9.Text = Convert.ToString(Math.Round(totalHour39 * Convert.ToDouble(rate9.Text)) + Math.Round(Convert.ToDouble(rate9.Text) * Convert.ToDouble(ot9.Text)));
                lblThurs9.Text = "$ " + lblThurs9.Text;
                totalPymt9.Text = lblThurs9.Text;
                totalPymt9.Text = lblThurs9.Text + m;

                m = Convert.ToDouble(totalPymt10.Text);
                totalPymt10.Text = "";
                hour80 = Convert.ToDouble(timeIn10.Text);
                hour79 = Convert.ToDouble(timeOut10.Text);
                totalHour40 = hour79 - hour80;
                hoursLabel10.Text = Convert.ToString(totalHour40 / 24);
                hoursLabel10.Text = Convert.ToString(totalHour40);
                lblThurs10.Text = Convert.ToString(Math.Round(totalHour40 * Convert.ToDouble(rate10.Text)) + Math.Round(Convert.ToDouble(rate10.Text) * Convert.ToDouble(ot10.Text)));
                lblThurs10.Text = "$ " + lblThurs10.Text;
                totalPymt10.Text = lblThurs10.Text;
                totalPymt10.Text = lblThurs10.Text + m;



            }
            //---------------------------------Calc for all Fri Entries-------------------------------------------------
            else if (radFri.Checked == true)
            {
                m = Convert.ToDouble(totalPymt1.Text);
                totalPymt1.Text = "";
                hour82 = Convert.ToDouble(timeIn1.Text);
                hour81 = Convert.ToDouble(timeOut1.Text);
                totalHour41 = hour81 - hour82;
                hoursLabel1.Text = Convert.ToString(totalHour41 / 24);
                hoursLabel1.Text = Convert.ToString(totalHour41);
                lblFri1.Text = Convert.ToString(Math.Round(totalHour41 * Convert.ToDouble(rate1.Text)) + Math.Round(Convert.ToDouble(rate1.Text) * Convert.ToDouble(ot1.Text)));
                lblFri1.Text = "$ " + lblFri1.Text;
                totalPymt1.Text = lblFri1.Text;
                totalPymt1.Text = lblFri1.Text + m;

                m = Convert.ToDouble(totalPymt2.Text);
                totalPymt2.Text = "";
                hour84 = Convert.ToDouble(timeIn2.Text);
                hour83 = Convert.ToDouble(timeOut2.Text);
                totalHour42 = hour83 - hour84;
                hoursLabel2.Text = Convert.ToString(totalHour42 / 24);
                hoursLabel2.Text = Convert.ToString(totalHour42);
                lblFri2.Text = Convert.ToString(Math.Round(totalHour42 * Convert.ToDouble(rate2.Text)) + Math.Round(Convert.ToDouble(rate2.Text) * Convert.ToDouble(ot2.Text)));
                lblFri2.Text = "$ " + lblFri2.Text;
                totalPymt2.Text = lblFri2.Text;
                totalPymt2.Text = lblFri2.Text + m;

                m = Convert.ToDouble(totalPymt3.Text);
                totalPymt3.Text = "";
                hour86 = Convert.ToDouble(timeIn3.Text);
                hour85 = Convert.ToDouble(timeOut3.Text);
                totalHour43 = hour85 - hour86;
                hoursLabel3.Text = Convert.ToString(totalHour43 / 24);
                hoursLabel3.Text = Convert.ToString(totalHour43);
                lblFri3.Text = Convert.ToString(Math.Round(totalHour43 * Convert.ToDouble(rate3.Text)) + Math.Round(Convert.ToDouble(rate3.Text) * Convert.ToDouble(ot3.Text)));
                lblFri3.Text = "$ " + lblFri3.Text;
                totalPymt3.Text = lblFri3.Text;
                totalPymt3.Text = lblFri3.Text + m;

                m = Convert.ToDouble(totalPymt4.Text);
                totalPymt4.Text = "";
                hour88 = Convert.ToDouble(timeIn4.Text);
                hour87 = Convert.ToDouble(timeOut4.Text);
                totalHour44 = hour87 - hour88;
                hoursLabel4.Text = Convert.ToString(totalHour44 / 24);
                hoursLabel4.Text = Convert.ToString(totalHour44);
                lblFri4.Text = Convert.ToString(Math.Round(totalHour44 * Convert.ToDouble(rate4.Text)) + Math.Round(Convert.ToDouble(rate4.Text) * Convert.ToDouble(ot4.Text)));
                lblFri4.Text = "$ " + lblFri4.Text;
                totalPymt4.Text = lblFri4.Text;
                totalPymt4.Text = lblFri4.Text + m;

                m = Convert.ToDouble(totalPymt5.Text);
                totalPymt5.Text = "";
                hour90 = Convert.ToDouble(timeIn5.Text);
                hour89 = Convert.ToDouble(timeOut5.Text);
                totalHour45 = hour89 - hour90;
                hoursLabel5.Text = Convert.ToString(totalHour45 / 24);
                hoursLabel5.Text = Convert.ToString(totalHour45);
                lblFri5.Text = Convert.ToString(Math.Round(totalHour45 * Convert.ToDouble(rate5.Text)) + Math.Round(Convert.ToDouble(rate5.Text) * Convert.ToDouble(ot5.Text)));
                lblFri5.Text = "$ " + lblFri5.Text;
                totalPymt5.Text = lblFri5.Text;
                totalPymt5.Text = lblFri5.Text + m;

                m = Convert.ToDouble(totalPymt6.Text);
                totalPymt6.Text = "";
                hour92 = Convert.ToDouble(timeIn6.Text);
                hour91 = Convert.ToDouble(timeOut6.Text);
                totalHour46 = hour91 - hour92;
                hoursLabel6.Text = Convert.ToString(totalHour46 / 24);
                hoursLabel6.Text = Convert.ToString(totalHour46);
                lblFri6.Text = Convert.ToString(Math.Round(totalHour46 * Convert.ToDouble(rate6.Text)) + Math.Round(Convert.ToDouble(rate6.Text) * Convert.ToDouble(ot6.Text)));
                lblFri6.Text = "$ " + lblFri6.Text;
                totalPymt6.Text = lblFri6.Text;
                totalPymt6.Text = lblFri6.Text + m;

                m = Convert.ToDouble(totalPymt7.Text);
                totalPymt7.Text = "";
                hour94 = Convert.ToDouble(timeIn7.Text);
                hour93 = Convert.ToDouble(timeOut7.Text);
                totalHour47 = hour93 - hour94;
                hoursLabel7.Text = Convert.ToString(totalHour47 / 24);
                hoursLabel7.Text = Convert.ToString(totalHour47);
                lblFri7.Text = Convert.ToString(Math.Round(totalHour47 * Convert.ToDouble(rate7.Text)) + Math.Round(Convert.ToDouble(rate7.Text) * Convert.ToDouble(ot7.Text)));
                lblFri7.Text = "$ " + lblFri7.Text;
                totalPymt7.Text = lblFri7.Text;
                totalPymt7.Text = lblFri7.Text + m;

                m = Convert.ToDouble(totalPymt8.Text);
                totalPymt8.Text = "";
                hour96 = Convert.ToDouble(timeIn8.Text);
                hour95 = Convert.ToDouble(timeOut8.Text);
                totalHour48 = hour95 - hour96;
                hoursLabel8.Text = Convert.ToString(totalHour48 / 24);
                hoursLabel8.Text = Convert.ToString(totalHour48);
                lblFri8.Text = Convert.ToString(Math.Round(totalHour48 * Convert.ToDouble(rate8.Text)) + Math.Round(Convert.ToDouble(rate8.Text) * Convert.ToDouble(ot8.Text)));
                lblFri8.Text = "$ " + lblFri8.Text;
                totalPymt8.Text = lblFri8.Text;
                totalPymt8.Text = lblFri8.Text + m;

                m = Convert.ToDouble(totalPymt9.Text);
                totalPymt9.Text = "";
                hour98 = Convert.ToDouble(timeIn9.Text);
                hour97 = Convert.ToDouble(timeOut9.Text);
                totalHour49 = hour97 - hour98;
                hoursLabel9.Text = Convert.ToString(totalHour49 / 24);
                hoursLabel9.Text = Convert.ToString(totalHour49);
                lblFri9.Text = Convert.ToString(Math.Round(totalHour49 * Convert.ToDouble(rate9.Text)) + Math.Round(Convert.ToDouble(rate9.Text) * Convert.ToDouble(ot9.Text)));
                lblFri9.Text = "$ " + lblFri9.Text;
                totalPymt9.Text = lblFri9.Text;
                totalPymt9.Text = lblFri9.Text + m;

                m = Convert.ToDouble(totalPymt10.Text);
                totalPymt10.Text = "";
                hour100 = Convert.ToDouble(timeIn10.Text);
                hour99 = Convert.ToDouble(timeOut10.Text);
                totalHour50 = hour99 - hour100;
                hoursLabel10.Text = Convert.ToString(totalHour50 / 24);
                hoursLabel10.Text = Convert.ToString(totalHour50);
                lblFri10.Text = Convert.ToString(Math.Round(totalHour50 * Convert.ToDouble(rate10.Text)) + Math.Round(Convert.ToDouble(rate10.Text) * Convert.ToDouble(ot10.Text)));
                lblFri10.Text = "$ " + lblFri10.Text;
                totalPymt10.Text = lblFri10.Text;
                totalPymt10.Text = lblFri10.Text + m;
            
            }
            else
            {
                totalPymt1.Text = "$ " + totalPymt1.Text;
                totalPymt2.Text = "$ " + totalPymt2.Text;
                totalPymt3.Text = "$ " + totalPymt3.Text;
                totalPymt4.Text = "$ " + totalPymt4.Text;
                totalPymt5.Text = "$ " + totalPymt5.Text;
                totalPymt6.Text = "$ " + totalPymt6.Text;
                totalPymt7.Text = "$ " + totalPymt7.Text;
                totalPymt8.Text = "$ " + totalPymt8.Text;
                totalPymt9.Text = "$ " + totalPymt9.Text;
                totalPymt10.Text = "$ " + totalPymt10.Text;

            }


        }

        private void resetButton_Click_1(object sender, EventArgs e)
        {
            //--------------------------------------------------------The reset button also sets everything to 0.
            timeIn1.Enabled = false;
            timeIn2.Enabled = false;
            timeIn3.Enabled = false;
            timeIn4.Enabled = false;
            timeIn5.Enabled = false;
            timeIn6.Enabled = false;
            timeIn7.Enabled = false;
            timeIn8.Enabled = false;
            timeIn9.Enabled = false;
            timeIn10.Enabled = false;

            timeOut1.Enabled = false;
            timeOut2.Enabled = false;
            timeOut3.Enabled = false;
            timeOut4.Enabled = false;
            timeOut5.Enabled = false;
            timeOut6.Enabled = false;
            timeOut7.Enabled = false;
            timeOut8.Enabled = false;
            timeOut9.Enabled = false;
            timeOut10.Enabled = false;


            //------------------------Setting 0-----------------------------------
            hoursLabel1.Text = "0";
            hoursLabel2.Text = "0";
            hoursLabel3.Text = "0";
            hoursLabel4.Text = "0";
            hoursLabel5.Text = "0";
            hoursLabel6.Text = "0";
            hoursLabel7.Text = "0";
            hoursLabel8.Text = "0";
            hoursLabel9.Text = "0";
            hoursLabel10.Text = "0";

            totalPymt1.Text = "0";
            totalPymt2.Text = "0";
            totalPymt3.Text = "0";
            totalPymt4.Text = "0";
            totalPymt5.Text = "0";
            totalPymt6.Text = "0";
            totalPymt7.Text = "0";
            totalPymt8.Text = "0";
            totalPymt9.Text = "0";
            totalPymt10.Text = "0";



            rate1.Text = "0";
            rate2.Text = "0";
            rate3.Text = "0";
            rate4.Text = "0";
            rate5.Text = "0";
            rate6.Text = "0";
            rate7.Text = "0";
            rate8.Text = "0";
            rate9.Text = "0";
            rate10.Text = "0";

            ot1.Text = "0";
            ot2.Text = "0";
            ot3.Text = "0";
            ot4.Text = "0";
            ot5.Text = "0";
            ot6.Text = "0";
            ot7.Text = "0";
            ot8.Text = "0";
            ot9.Text = "0";
            ot10.Text = "0";

            timeOut1.Text = "0";
            timeOut2.Text = "0";
            timeOut3.Text = "0";
            timeOut4.Text = "0";
            timeOut5.Text = "0";
            timeOut6.Text = "0";
            timeOut7.Text = "0";
            timeOut8.Text = "0";
            timeOut9.Text = "0";
            timeOut10.Text = "0";

            timeIn1.Text = "0";
            timeIn2.Text = "0";
            timeIn3.Text = "0";
            timeIn4.Text = "0";
            timeIn5.Text = "0";
            timeIn6.Text = "0";
            timeIn7.Text = "0";
            timeIn8.Text = "0";
            timeIn9.Text = "0";
            timeIn10.Text = "0";

            lblMon1.Text = "0";
            lblMon2.Text = "0";
            lblMon3.Text = "0";
            lblMon4.Text = "0";
            lblMon5.Text = "0";
            lblMon6.Text = "0";
            lblMon7.Text = "0";
            lblMon8.Text = "0";
            lblMon9.Text = "0";
            lblMon10.Text = "0";

            lblTues1.Text = "0";
            lblTues2.Text = "0";
            lblTues3.Text = "0";
            lblTues4.Text = "0";
            lblTues5.Text = "0";
            lblTues6.Text = "0";
            lblTues7.Text = "0";
            lblTues8.Text = "0";
            lblTues9.Text = "0";
            lblTues10.Text = "0";

            lblWed1.Text = "0";
            lblWed2.Text = "0";
            lblWed3.Text = "0";
            lblWed4.Text = "0";
            lblWed5.Text = "0";
            lblWed6.Text = "0";
            lblWed7.Text = "0";
            lblWed8.Text = "0";
            lblWed9.Text = "0";
            lblWed10.Text = "0";

            lblThurs1.Text = "0";
            lblThurs2.Text = "0";
            lblThurs3.Text = "0";
            lblThurs4.Text = "0";
            lblThurs5.Text = "0";
            lblThurs6.Text = "0";
            lblThurs7.Text = "0";
            lblThurs8.Text = "0";
            lblThurs9.Text = "0";
            lblThurs10.Text = "0";

            lblFri1.Text = "0";
            lblFri2.Text = "0";
            lblFri3.Text = "0";
            lblFri4.Text = "0";
            lblFri5.Text = "0";
            lblFri6.Text = "0";
            lblFri7.Text = "0";
            lblFri8.Text = "0";
            lblFri9.Text = "0";
            lblFri10.Text = "0";


        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}