﻿namespace timeSheet
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.totalWageButton = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.totalPymt10 = new System.Windows.Forms.TextBox();
            this.totalPymt9 = new System.Windows.Forms.TextBox();
            this.totalPymt8 = new System.Windows.Forms.TextBox();
            this.totalPymt7 = new System.Windows.Forms.TextBox();
            this.totalPymt6 = new System.Windows.Forms.TextBox();
            this.totalPymt5 = new System.Windows.Forms.TextBox();
            this.totalPymt4 = new System.Windows.Forms.TextBox();
            this.totalPymt3 = new System.Windows.Forms.TextBox();
            this.totalPymt2 = new System.Windows.Forms.TextBox();
            this.totalPymt1 = new System.Windows.Forms.TextBox();
            this.lblFri10 = new System.Windows.Forms.TextBox();
            this.lblFri9 = new System.Windows.Forms.TextBox();
            this.lblFri8 = new System.Windows.Forms.TextBox();
            this.lblFri7 = new System.Windows.Forms.TextBox();
            this.lblFri6 = new System.Windows.Forms.TextBox();
            this.lblFri5 = new System.Windows.Forms.TextBox();
            this.lblFri4 = new System.Windows.Forms.TextBox();
            this.lblFri3 = new System.Windows.Forms.TextBox();
            this.lblFri2 = new System.Windows.Forms.TextBox();
            this.lblFri1 = new System.Windows.Forms.TextBox();
            this.lblThurs10 = new System.Windows.Forms.TextBox();
            this.lblThurs9 = new System.Windows.Forms.TextBox();
            this.lblThurs8 = new System.Windows.Forms.TextBox();
            this.lblThurs7 = new System.Windows.Forms.TextBox();
            this.lblThurs6 = new System.Windows.Forms.TextBox();
            this.lblThurs5 = new System.Windows.Forms.TextBox();
            this.lblThurs4 = new System.Windows.Forms.TextBox();
            this.lblThurs3 = new System.Windows.Forms.TextBox();
            this.lblThurs2 = new System.Windows.Forms.TextBox();
            this.lblThurs1 = new System.Windows.Forms.TextBox();
            this.lblWed10 = new System.Windows.Forms.TextBox();
            this.lblWed9 = new System.Windows.Forms.TextBox();
            this.lblWed8 = new System.Windows.Forms.TextBox();
            this.lblWed7 = new System.Windows.Forms.TextBox();
            this.lblWed6 = new System.Windows.Forms.TextBox();
            this.lblWed5 = new System.Windows.Forms.TextBox();
            this.lblWed4 = new System.Windows.Forms.TextBox();
            this.lblWed3 = new System.Windows.Forms.TextBox();
            this.lblWed2 = new System.Windows.Forms.TextBox();
            this.lblWed1 = new System.Windows.Forms.TextBox();
            this.lblTues10 = new System.Windows.Forms.TextBox();
            this.lblTues9 = new System.Windows.Forms.TextBox();
            this.lblTues8 = new System.Windows.Forms.TextBox();
            this.lblTues7 = new System.Windows.Forms.TextBox();
            this.lblTues6 = new System.Windows.Forms.TextBox();
            this.lblTues5 = new System.Windows.Forms.TextBox();
            this.lblTues4 = new System.Windows.Forms.TextBox();
            this.lblTues3 = new System.Windows.Forms.TextBox();
            this.lblTues2 = new System.Windows.Forms.TextBox();
            this.lblTues1 = new System.Windows.Forms.TextBox();
            this.lblMon10 = new System.Windows.Forms.TextBox();
            this.lblMon9 = new System.Windows.Forms.TextBox();
            this.lblMon8 = new System.Windows.Forms.TextBox();
            this.lblMon7 = new System.Windows.Forms.TextBox();
            this.lblMon6 = new System.Windows.Forms.TextBox();
            this.lblMon5 = new System.Windows.Forms.TextBox();
            this.lblMon4 = new System.Windows.Forms.TextBox();
            this.lblMon3 = new System.Windows.Forms.TextBox();
            this.lblMon2 = new System.Windows.Forms.TextBox();
            this.lblMon1 = new System.Windows.Forms.TextBox();
            this.radFri = new System.Windows.Forms.RadioButton();
            this.radThurs = new System.Windows.Forms.RadioButton();
            this.radWed = new System.Windows.Forms.RadioButton();
            this.radTues = new System.Windows.Forms.RadioButton();
            this.radMon = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.hoursLabel10 = new System.Windows.Forms.TextBox();
            this.hoursLabel9 = new System.Windows.Forms.TextBox();
            this.hoursLabel8 = new System.Windows.Forms.TextBox();
            this.hoursLabel7 = new System.Windows.Forms.TextBox();
            this.hoursLabel6 = new System.Windows.Forms.TextBox();
            this.hoursLabel5 = new System.Windows.Forms.TextBox();
            this.hoursLabel4 = new System.Windows.Forms.TextBox();
            this.hoursLabel3 = new System.Windows.Forms.TextBox();
            this.hoursLabel2 = new System.Windows.Forms.TextBox();
            this.hoursLabel1 = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.rate1 = new System.Windows.Forms.ComboBox();
            this.rate10 = new System.Windows.Forms.ComboBox();
            this.rate9 = new System.Windows.Forms.ComboBox();
            this.rate8 = new System.Windows.Forms.ComboBox();
            this.rate7 = new System.Windows.Forms.ComboBox();
            this.rate6 = new System.Windows.Forms.ComboBox();
            this.rate5 = new System.Windows.Forms.ComboBox();
            this.rate4 = new System.Windows.Forms.ComboBox();
            this.rate3 = new System.Windows.Forms.ComboBox();
            this.rate2 = new System.Windows.Forms.ComboBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.ot7 = new System.Windows.Forms.ComboBox();
            this.ot10 = new System.Windows.Forms.ComboBox();
            this.ot9 = new System.Windows.Forms.ComboBox();
            this.ot8 = new System.Windows.Forms.ComboBox();
            this.ot6 = new System.Windows.Forms.ComboBox();
            this.ot5 = new System.Windows.Forms.ComboBox();
            this.ot4 = new System.Windows.Forms.ComboBox();
            this.ot3 = new System.Windows.Forms.ComboBox();
            this.ot2 = new System.Windows.Forms.ComboBox();
            this.ot1 = new System.Windows.Forms.ComboBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.timeIn1 = new System.Windows.Forms.TextBox();
            this.timeIn10 = new System.Windows.Forms.TextBox();
            this.timeIn9 = new System.Windows.Forms.TextBox();
            this.timeIn8 = new System.Windows.Forms.TextBox();
            this.timeIn7 = new System.Windows.Forms.TextBox();
            this.timeIn6 = new System.Windows.Forms.TextBox();
            this.timeIn5 = new System.Windows.Forms.TextBox();
            this.timeIn4 = new System.Windows.Forms.TextBox();
            this.timeIn3 = new System.Windows.Forms.TextBox();
            this.timeIn2 = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.timeOut1 = new System.Windows.Forms.TextBox();
            this.timeOut10 = new System.Windows.Forms.TextBox();
            this.timeOut9 = new System.Windows.Forms.TextBox();
            this.timeOut8 = new System.Windows.Forms.TextBox();
            this.timeOut7 = new System.Windows.Forms.TextBox();
            this.timeOut6 = new System.Windows.Forms.TextBox();
            this.timeOut5 = new System.Windows.Forms.TextBox();
            this.timeOut4 = new System.Windows.Forms.TextBox();
            this.timeOut3 = new System.Windows.Forms.TextBox();
            this.timeOut2 = new System.Windows.Forms.TextBox();
            this.radTotalWage = new System.Windows.Forms.RadioButton();
            this.resetButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.GrayText;
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox1.Location = new System.Drawing.Point(1, 1);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1352, 72);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(502, 22);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(373, 37);
            this.label11.TabIndex = 0;
            this.label11.Text = "The Weekly Time Chart";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.GrayText;
            this.groupBox2.Controls.Add(this.exitButton);
            this.groupBox2.Controls.Add(this.resetButton);
            this.groupBox2.Controls.Add(this.totalWageButton);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox2.Location = new System.Drawing.Point(1, 563);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1352, 85);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // totalWageButton
            // 
            this.totalWageButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.totalWageButton.Location = new System.Drawing.Point(316, 25);
            this.totalWageButton.Name = "totalWageButton";
            this.totalWageButton.Size = new System.Drawing.Size(177, 40);
            this.totalWageButton.TabIndex = 0;
            this.totalWageButton.Text = "Total Wages";
            this.totalWageButton.UseVisualStyleBackColor = true;
            this.totalWageButton.Click += new System.EventHandler(this.totalWageButton_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.GrayText;
            this.groupBox3.Controls.Add(this.radTotalWage);
            this.groupBox3.Controls.Add(this.totalPymt10);
            this.groupBox3.Controls.Add(this.totalPymt9);
            this.groupBox3.Controls.Add(this.totalPymt8);
            this.groupBox3.Controls.Add(this.totalPymt7);
            this.groupBox3.Controls.Add(this.totalPymt6);
            this.groupBox3.Controls.Add(this.totalPymt5);
            this.groupBox3.Controls.Add(this.totalPymt4);
            this.groupBox3.Controls.Add(this.totalPymt3);
            this.groupBox3.Controls.Add(this.totalPymt2);
            this.groupBox3.Controls.Add(this.totalPymt1);
            this.groupBox3.Controls.Add(this.lblFri10);
            this.groupBox3.Controls.Add(this.lblFri9);
            this.groupBox3.Controls.Add(this.lblFri8);
            this.groupBox3.Controls.Add(this.lblFri7);
            this.groupBox3.Controls.Add(this.lblFri6);
            this.groupBox3.Controls.Add(this.lblFri5);
            this.groupBox3.Controls.Add(this.lblFri4);
            this.groupBox3.Controls.Add(this.lblFri3);
            this.groupBox3.Controls.Add(this.lblFri2);
            this.groupBox3.Controls.Add(this.lblFri1);
            this.groupBox3.Controls.Add(this.lblThurs10);
            this.groupBox3.Controls.Add(this.lblThurs9);
            this.groupBox3.Controls.Add(this.lblThurs8);
            this.groupBox3.Controls.Add(this.lblThurs7);
            this.groupBox3.Controls.Add(this.lblThurs6);
            this.groupBox3.Controls.Add(this.lblThurs5);
            this.groupBox3.Controls.Add(this.lblThurs4);
            this.groupBox3.Controls.Add(this.lblThurs3);
            this.groupBox3.Controls.Add(this.lblThurs2);
            this.groupBox3.Controls.Add(this.lblThurs1);
            this.groupBox3.Controls.Add(this.lblWed10);
            this.groupBox3.Controls.Add(this.lblWed9);
            this.groupBox3.Controls.Add(this.lblWed8);
            this.groupBox3.Controls.Add(this.lblWed7);
            this.groupBox3.Controls.Add(this.lblWed6);
            this.groupBox3.Controls.Add(this.lblWed5);
            this.groupBox3.Controls.Add(this.lblWed4);
            this.groupBox3.Controls.Add(this.lblWed3);
            this.groupBox3.Controls.Add(this.lblWed2);
            this.groupBox3.Controls.Add(this.lblWed1);
            this.groupBox3.Controls.Add(this.lblTues10);
            this.groupBox3.Controls.Add(this.lblTues9);
            this.groupBox3.Controls.Add(this.lblTues8);
            this.groupBox3.Controls.Add(this.lblTues7);
            this.groupBox3.Controls.Add(this.lblTues6);
            this.groupBox3.Controls.Add(this.lblTues5);
            this.groupBox3.Controls.Add(this.lblTues4);
            this.groupBox3.Controls.Add(this.lblTues3);
            this.groupBox3.Controls.Add(this.lblTues2);
            this.groupBox3.Controls.Add(this.lblTues1);
            this.groupBox3.Controls.Add(this.lblMon10);
            this.groupBox3.Controls.Add(this.lblMon9);
            this.groupBox3.Controls.Add(this.lblMon8);
            this.groupBox3.Controls.Add(this.lblMon7);
            this.groupBox3.Controls.Add(this.lblMon6);
            this.groupBox3.Controls.Add(this.lblMon5);
            this.groupBox3.Controls.Add(this.lblMon4);
            this.groupBox3.Controls.Add(this.lblMon3);
            this.groupBox3.Controls.Add(this.lblMon2);
            this.groupBox3.Controls.Add(this.lblMon1);
            this.groupBox3.Controls.Add(this.radFri);
            this.groupBox3.Controls.Add(this.radThurs);
            this.groupBox3.Controls.Add(this.radWed);
            this.groupBox3.Controls.Add(this.radTues);
            this.groupBox3.Controls.Add(this.radMon);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox3.Location = new System.Drawing.Point(748, 79);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(594, 478);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            // 
            // totalPymt10
            // 
            this.totalPymt10.Location = new System.Drawing.Point(497, 430);
            this.totalPymt10.Name = "totalPymt10";
            this.totalPymt10.Size = new System.Drawing.Size(74, 26);
            this.totalPymt10.TabIndex = 65;
            this.totalPymt10.Text = "0";
            this.totalPymt10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // totalPymt9
            // 
            this.totalPymt9.Location = new System.Drawing.Point(497, 384);
            this.totalPymt9.Name = "totalPymt9";
            this.totalPymt9.Size = new System.Drawing.Size(74, 26);
            this.totalPymt9.TabIndex = 64;
            this.totalPymt9.Text = "0";
            this.totalPymt9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // totalPymt8
            // 
            this.totalPymt8.Location = new System.Drawing.Point(497, 338);
            this.totalPymt8.Name = "totalPymt8";
            this.totalPymt8.Size = new System.Drawing.Size(74, 26);
            this.totalPymt8.TabIndex = 63;
            this.totalPymt8.Text = "0";
            this.totalPymt8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // totalPymt7
            // 
            this.totalPymt7.Location = new System.Drawing.Point(497, 295);
            this.totalPymt7.Name = "totalPymt7";
            this.totalPymt7.Size = new System.Drawing.Size(74, 26);
            this.totalPymt7.TabIndex = 62;
            this.totalPymt7.Text = "0";
            this.totalPymt7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // totalPymt6
            // 
            this.totalPymt6.Location = new System.Drawing.Point(497, 249);
            this.totalPymt6.Name = "totalPymt6";
            this.totalPymt6.Size = new System.Drawing.Size(74, 26);
            this.totalPymt6.TabIndex = 61;
            this.totalPymt6.Text = "0";
            this.totalPymt6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // totalPymt5
            // 
            this.totalPymt5.Location = new System.Drawing.Point(497, 206);
            this.totalPymt5.Name = "totalPymt5";
            this.totalPymt5.Size = new System.Drawing.Size(74, 26);
            this.totalPymt5.TabIndex = 60;
            this.totalPymt5.Text = "0";
            this.totalPymt5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // totalPymt4
            // 
            this.totalPymt4.Location = new System.Drawing.Point(497, 163);
            this.totalPymt4.Name = "totalPymt4";
            this.totalPymt4.Size = new System.Drawing.Size(74, 26);
            this.totalPymt4.TabIndex = 59;
            this.totalPymt4.Text = "0";
            this.totalPymt4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // totalPymt3
            // 
            this.totalPymt3.Location = new System.Drawing.Point(497, 122);
            this.totalPymt3.Name = "totalPymt3";
            this.totalPymt3.Size = new System.Drawing.Size(74, 26);
            this.totalPymt3.TabIndex = 58;
            this.totalPymt3.Text = "0";
            this.totalPymt3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // totalPymt2
            // 
            this.totalPymt2.Location = new System.Drawing.Point(497, 78);
            this.totalPymt2.Name = "totalPymt2";
            this.totalPymt2.Size = new System.Drawing.Size(74, 26);
            this.totalPymt2.TabIndex = 57;
            this.totalPymt2.Text = "0";
            this.totalPymt2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // totalPymt1
            // 
            this.totalPymt1.Location = new System.Drawing.Point(497, 35);
            this.totalPymt1.Name = "totalPymt1";
            this.totalPymt1.Size = new System.Drawing.Size(74, 26);
            this.totalPymt1.TabIndex = 56;
            this.totalPymt1.Text = "0";
            this.totalPymt1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblFri10
            // 
            this.lblFri10.Location = new System.Drawing.Point(404, 430);
            this.lblFri10.Name = "lblFri10";
            this.lblFri10.Size = new System.Drawing.Size(75, 26);
            this.lblFri10.TabIndex = 54;
            this.lblFri10.Text = "0";
            this.lblFri10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblFri9
            // 
            this.lblFri9.Location = new System.Drawing.Point(404, 384);
            this.lblFri9.Name = "lblFri9";
            this.lblFri9.Size = new System.Drawing.Size(75, 26);
            this.lblFri9.TabIndex = 53;
            this.lblFri9.Text = "0";
            this.lblFri9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblFri8
            // 
            this.lblFri8.Location = new System.Drawing.Point(404, 338);
            this.lblFri8.Name = "lblFri8";
            this.lblFri8.Size = new System.Drawing.Size(75, 26);
            this.lblFri8.TabIndex = 52;
            this.lblFri8.Text = "0";
            this.lblFri8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblFri7
            // 
            this.lblFri7.Location = new System.Drawing.Point(404, 295);
            this.lblFri7.Name = "lblFri7";
            this.lblFri7.Size = new System.Drawing.Size(75, 26);
            this.lblFri7.TabIndex = 51;
            this.lblFri7.Text = "0";
            this.lblFri7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblFri6
            // 
            this.lblFri6.Location = new System.Drawing.Point(404, 250);
            this.lblFri6.Name = "lblFri6";
            this.lblFri6.Size = new System.Drawing.Size(75, 26);
            this.lblFri6.TabIndex = 50;
            this.lblFri6.Text = "0";
            this.lblFri6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblFri5
            // 
            this.lblFri5.Location = new System.Drawing.Point(404, 206);
            this.lblFri5.Name = "lblFri5";
            this.lblFri5.Size = new System.Drawing.Size(75, 26);
            this.lblFri5.TabIndex = 49;
            this.lblFri5.Text = "0";
            this.lblFri5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblFri4
            // 
            this.lblFri4.Location = new System.Drawing.Point(404, 163);
            this.lblFri4.Name = "lblFri4";
            this.lblFri4.Size = new System.Drawing.Size(75, 26);
            this.lblFri4.TabIndex = 48;
            this.lblFri4.Text = "0";
            this.lblFri4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblFri3
            // 
            this.lblFri3.Location = new System.Drawing.Point(404, 122);
            this.lblFri3.Name = "lblFri3";
            this.lblFri3.Size = new System.Drawing.Size(75, 26);
            this.lblFri3.TabIndex = 47;
            this.lblFri3.Text = "0";
            this.lblFri3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblFri2
            // 
            this.lblFri2.Location = new System.Drawing.Point(404, 80);
            this.lblFri2.Name = "lblFri2";
            this.lblFri2.Size = new System.Drawing.Size(75, 26);
            this.lblFri2.TabIndex = 46;
            this.lblFri2.Text = "0";
            this.lblFri2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblFri1
            // 
            this.lblFri1.Location = new System.Drawing.Point(404, 35);
            this.lblFri1.Name = "lblFri1";
            this.lblFri1.Size = new System.Drawing.Size(75, 26);
            this.lblFri1.TabIndex = 45;
            this.lblFri1.Text = "0";
            this.lblFri1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblThurs10
            // 
            this.lblThurs10.Location = new System.Drawing.Point(314, 431);
            this.lblThurs10.Name = "lblThurs10";
            this.lblThurs10.Size = new System.Drawing.Size(75, 26);
            this.lblThurs10.TabIndex = 44;
            this.lblThurs10.Text = "0";
            this.lblThurs10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblThurs9
            // 
            this.lblThurs9.Location = new System.Drawing.Point(314, 385);
            this.lblThurs9.Name = "lblThurs9";
            this.lblThurs9.Size = new System.Drawing.Size(75, 26);
            this.lblThurs9.TabIndex = 43;
            this.lblThurs9.Text = "0";
            this.lblThurs9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblThurs8
            // 
            this.lblThurs8.Location = new System.Drawing.Point(314, 339);
            this.lblThurs8.Name = "lblThurs8";
            this.lblThurs8.Size = new System.Drawing.Size(75, 26);
            this.lblThurs8.TabIndex = 42;
            this.lblThurs8.Text = "0";
            this.lblThurs8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblThurs7
            // 
            this.lblThurs7.Location = new System.Drawing.Point(314, 296);
            this.lblThurs7.Name = "lblThurs7";
            this.lblThurs7.Size = new System.Drawing.Size(75, 26);
            this.lblThurs7.TabIndex = 41;
            this.lblThurs7.Text = "0";
            this.lblThurs7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblThurs6
            // 
            this.lblThurs6.Location = new System.Drawing.Point(314, 251);
            this.lblThurs6.Name = "lblThurs6";
            this.lblThurs6.Size = new System.Drawing.Size(75, 26);
            this.lblThurs6.TabIndex = 40;
            this.lblThurs6.Text = "0";
            this.lblThurs6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblThurs5
            // 
            this.lblThurs5.Location = new System.Drawing.Point(314, 207);
            this.lblThurs5.Name = "lblThurs5";
            this.lblThurs5.Size = new System.Drawing.Size(75, 26);
            this.lblThurs5.TabIndex = 39;
            this.lblThurs5.Text = "0";
            this.lblThurs5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblThurs4
            // 
            this.lblThurs4.Location = new System.Drawing.Point(314, 164);
            this.lblThurs4.Name = "lblThurs4";
            this.lblThurs4.Size = new System.Drawing.Size(75, 26);
            this.lblThurs4.TabIndex = 38;
            this.lblThurs4.Text = "0";
            this.lblThurs4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblThurs3
            // 
            this.lblThurs3.Location = new System.Drawing.Point(314, 123);
            this.lblThurs3.Name = "lblThurs3";
            this.lblThurs3.Size = new System.Drawing.Size(75, 26);
            this.lblThurs3.TabIndex = 37;
            this.lblThurs3.Text = "0";
            this.lblThurs3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblThurs2
            // 
            this.lblThurs2.Location = new System.Drawing.Point(314, 81);
            this.lblThurs2.Name = "lblThurs2";
            this.lblThurs2.Size = new System.Drawing.Size(75, 26);
            this.lblThurs2.TabIndex = 36;
            this.lblThurs2.Text = "0";
            this.lblThurs2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblThurs1
            // 
            this.lblThurs1.Location = new System.Drawing.Point(314, 36);
            this.lblThurs1.Name = "lblThurs1";
            this.lblThurs1.Size = new System.Drawing.Size(75, 26);
            this.lblThurs1.TabIndex = 35;
            this.lblThurs1.Text = "0";
            this.lblThurs1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblWed10
            // 
            this.lblWed10.Location = new System.Drawing.Point(208, 430);
            this.lblWed10.Name = "lblWed10";
            this.lblWed10.Size = new System.Drawing.Size(75, 26);
            this.lblWed10.TabIndex = 34;
            this.lblWed10.Text = "0";
            this.lblWed10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblWed9
            // 
            this.lblWed9.Location = new System.Drawing.Point(208, 384);
            this.lblWed9.Name = "lblWed9";
            this.lblWed9.Size = new System.Drawing.Size(75, 26);
            this.lblWed9.TabIndex = 33;
            this.lblWed9.Text = "0";
            this.lblWed9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblWed8
            // 
            this.lblWed8.Location = new System.Drawing.Point(208, 338);
            this.lblWed8.Name = "lblWed8";
            this.lblWed8.Size = new System.Drawing.Size(75, 26);
            this.lblWed8.TabIndex = 32;
            this.lblWed8.Text = "0";
            this.lblWed8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblWed7
            // 
            this.lblWed7.Location = new System.Drawing.Point(208, 295);
            this.lblWed7.Name = "lblWed7";
            this.lblWed7.Size = new System.Drawing.Size(75, 26);
            this.lblWed7.TabIndex = 31;
            this.lblWed7.Text = "0";
            this.lblWed7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblWed6
            // 
            this.lblWed6.Location = new System.Drawing.Point(208, 250);
            this.lblWed6.Name = "lblWed6";
            this.lblWed6.Size = new System.Drawing.Size(75, 26);
            this.lblWed6.TabIndex = 30;
            this.lblWed6.Text = "0";
            this.lblWed6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblWed5
            // 
            this.lblWed5.Location = new System.Drawing.Point(208, 206);
            this.lblWed5.Name = "lblWed5";
            this.lblWed5.Size = new System.Drawing.Size(75, 26);
            this.lblWed5.TabIndex = 29;
            this.lblWed5.Text = "0";
            this.lblWed5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblWed4
            // 
            this.lblWed4.Location = new System.Drawing.Point(208, 163);
            this.lblWed4.Name = "lblWed4";
            this.lblWed4.Size = new System.Drawing.Size(75, 26);
            this.lblWed4.TabIndex = 28;
            this.lblWed4.Text = "0";
            this.lblWed4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblWed3
            // 
            this.lblWed3.Location = new System.Drawing.Point(208, 122);
            this.lblWed3.Name = "lblWed3";
            this.lblWed3.Size = new System.Drawing.Size(75, 26);
            this.lblWed3.TabIndex = 27;
            this.lblWed3.Text = "0";
            this.lblWed3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblWed2
            // 
            this.lblWed2.Location = new System.Drawing.Point(208, 80);
            this.lblWed2.Name = "lblWed2";
            this.lblWed2.Size = new System.Drawing.Size(75, 26);
            this.lblWed2.TabIndex = 26;
            this.lblWed2.Text = "0";
            this.lblWed2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblWed1
            // 
            this.lblWed1.Location = new System.Drawing.Point(208, 36);
            this.lblWed1.Name = "lblWed1";
            this.lblWed1.Size = new System.Drawing.Size(75, 26);
            this.lblWed1.TabIndex = 25;
            this.lblWed1.Text = "0";
            this.lblWed1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblTues10
            // 
            this.lblTues10.Location = new System.Drawing.Point(111, 430);
            this.lblTues10.Name = "lblTues10";
            this.lblTues10.Size = new System.Drawing.Size(75, 26);
            this.lblTues10.TabIndex = 24;
            this.lblTues10.Text = "0";
            this.lblTues10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblTues9
            // 
            this.lblTues9.Location = new System.Drawing.Point(111, 384);
            this.lblTues9.Name = "lblTues9";
            this.lblTues9.Size = new System.Drawing.Size(75, 26);
            this.lblTues9.TabIndex = 23;
            this.lblTues9.Text = "0";
            this.lblTues9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblTues8
            // 
            this.lblTues8.Location = new System.Drawing.Point(111, 338);
            this.lblTues8.Name = "lblTues8";
            this.lblTues8.Size = new System.Drawing.Size(75, 26);
            this.lblTues8.TabIndex = 22;
            this.lblTues8.Text = "0";
            this.lblTues8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblTues7
            // 
            this.lblTues7.Location = new System.Drawing.Point(111, 295);
            this.lblTues7.Name = "lblTues7";
            this.lblTues7.Size = new System.Drawing.Size(75, 26);
            this.lblTues7.TabIndex = 21;
            this.lblTues7.Text = "0";
            this.lblTues7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblTues6
            // 
            this.lblTues6.Location = new System.Drawing.Point(111, 250);
            this.lblTues6.Name = "lblTues6";
            this.lblTues6.Size = new System.Drawing.Size(75, 26);
            this.lblTues6.TabIndex = 20;
            this.lblTues6.Text = "0";
            this.lblTues6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblTues5
            // 
            this.lblTues5.Location = new System.Drawing.Point(111, 206);
            this.lblTues5.Name = "lblTues5";
            this.lblTues5.Size = new System.Drawing.Size(75, 26);
            this.lblTues5.TabIndex = 19;
            this.lblTues5.Text = "0";
            this.lblTues5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblTues4
            // 
            this.lblTues4.Location = new System.Drawing.Point(111, 163);
            this.lblTues4.Name = "lblTues4";
            this.lblTues4.Size = new System.Drawing.Size(75, 26);
            this.lblTues4.TabIndex = 18;
            this.lblTues4.Text = "0";
            this.lblTues4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblTues3
            // 
            this.lblTues3.Location = new System.Drawing.Point(111, 122);
            this.lblTues3.Name = "lblTues3";
            this.lblTues3.Size = new System.Drawing.Size(75, 26);
            this.lblTues3.TabIndex = 17;
            this.lblTues3.Text = "0";
            this.lblTues3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblTues2
            // 
            this.lblTues2.Location = new System.Drawing.Point(111, 80);
            this.lblTues2.Name = "lblTues2";
            this.lblTues2.Size = new System.Drawing.Size(75, 26);
            this.lblTues2.TabIndex = 16;
            this.lblTues2.Text = "0";
            this.lblTues2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblTues1
            // 
            this.lblTues1.Location = new System.Drawing.Point(111, 35);
            this.lblTues1.Name = "lblTues1";
            this.lblTues1.Size = new System.Drawing.Size(75, 26);
            this.lblTues1.TabIndex = 15;
            this.lblTues1.Text = "0";
            this.lblTues1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblMon10
            // 
            this.lblMon10.Location = new System.Drawing.Point(19, 431);
            this.lblMon10.Name = "lblMon10";
            this.lblMon10.Size = new System.Drawing.Size(67, 26);
            this.lblMon10.TabIndex = 14;
            this.lblMon10.Text = "0";
            this.lblMon10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblMon9
            // 
            this.lblMon9.Location = new System.Drawing.Point(19, 385);
            this.lblMon9.Name = "lblMon9";
            this.lblMon9.Size = new System.Drawing.Size(67, 26);
            this.lblMon9.TabIndex = 13;
            this.lblMon9.Text = "0";
            this.lblMon9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblMon8
            // 
            this.lblMon8.Location = new System.Drawing.Point(19, 339);
            this.lblMon8.Name = "lblMon8";
            this.lblMon8.Size = new System.Drawing.Size(67, 26);
            this.lblMon8.TabIndex = 12;
            this.lblMon8.Text = "0";
            this.lblMon8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblMon7
            // 
            this.lblMon7.Location = new System.Drawing.Point(19, 296);
            this.lblMon7.Name = "lblMon7";
            this.lblMon7.Size = new System.Drawing.Size(67, 26);
            this.lblMon7.TabIndex = 11;
            this.lblMon7.Text = "0";
            this.lblMon7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblMon6
            // 
            this.lblMon6.Location = new System.Drawing.Point(19, 251);
            this.lblMon6.Name = "lblMon6";
            this.lblMon6.Size = new System.Drawing.Size(67, 26);
            this.lblMon6.TabIndex = 10;
            this.lblMon6.Text = "0";
            this.lblMon6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblMon5
            // 
            this.lblMon5.Location = new System.Drawing.Point(19, 207);
            this.lblMon5.Name = "lblMon5";
            this.lblMon5.Size = new System.Drawing.Size(67, 26);
            this.lblMon5.TabIndex = 9;
            this.lblMon5.Text = "0";
            this.lblMon5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblMon4
            // 
            this.lblMon4.Location = new System.Drawing.Point(19, 164);
            this.lblMon4.Name = "lblMon4";
            this.lblMon4.Size = new System.Drawing.Size(67, 26);
            this.lblMon4.TabIndex = 8;
            this.lblMon4.Text = "0";
            this.lblMon4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblMon3
            // 
            this.lblMon3.Location = new System.Drawing.Point(19, 123);
            this.lblMon3.Name = "lblMon3";
            this.lblMon3.Size = new System.Drawing.Size(67, 26);
            this.lblMon3.TabIndex = 7;
            this.lblMon3.Text = "0";
            this.lblMon3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblMon2
            // 
            this.lblMon2.Location = new System.Drawing.Point(19, 81);
            this.lblMon2.Name = "lblMon2";
            this.lblMon2.Size = new System.Drawing.Size(67, 26);
            this.lblMon2.TabIndex = 6;
            this.lblMon2.Text = "0";
            this.lblMon2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblMon1
            // 
            this.lblMon1.Location = new System.Drawing.Point(19, 36);
            this.lblMon1.Name = "lblMon1";
            this.lblMon1.Size = new System.Drawing.Size(67, 26);
            this.lblMon1.TabIndex = 5;
            this.lblMon1.Text = "0";
            this.lblMon1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // radFri
            // 
            this.radFri.AutoSize = true;
            this.radFri.Location = new System.Drawing.Point(395, 14);
            this.radFri.Name = "radFri";
            this.radFri.Size = new System.Drawing.Size(76, 24);
            this.radFri.TabIndex = 4;
            this.radFri.TabStop = true;
            this.radFri.Text = "Friday";
            this.radFri.UseVisualStyleBackColor = true;
            this.radFri.CheckedChanged += new System.EventHandler(this.radFri_CheckedChanged);
            // 
            // radThurs
            // 
            this.radThurs.AutoSize = true;
            this.radThurs.Location = new System.Drawing.Point(298, 14);
            this.radThurs.Name = "radThurs";
            this.radThurs.Size = new System.Drawing.Size(100, 24);
            this.radThurs.TabIndex = 3;
            this.radThurs.TabStop = true;
            this.radThurs.Text = "Thursday";
            this.radThurs.UseVisualStyleBackColor = true;
            this.radThurs.CheckedChanged += new System.EventHandler(this.radThurs_CheckedChanged);
            // 
            // radWed
            // 
            this.radWed.AutoSize = true;
            this.radWed.Location = new System.Drawing.Point(182, 14);
            this.radWed.Name = "radWed";
            this.radWed.Size = new System.Drawing.Size(120, 24);
            this.radWed.TabIndex = 2;
            this.radWed.TabStop = true;
            this.radWed.Text = "Wednesday";
            this.radWed.UseVisualStyleBackColor = true;
            this.radWed.CheckedChanged += new System.EventHandler(this.radWed_CheckedChanged);
            // 
            // radTues
            // 
            this.radTues.AutoSize = true;
            this.radTues.Location = new System.Drawing.Point(92, 14);
            this.radTues.Name = "radTues";
            this.radTues.Size = new System.Drawing.Size(94, 24);
            this.radTues.TabIndex = 1;
            this.radTues.TabStop = true;
            this.radTues.Text = "Tuesday";
            this.radTues.UseVisualStyleBackColor = true;
            this.radTues.CheckedChanged += new System.EventHandler(this.radTues_CheckedChanged);
            // 
            // radMon
            // 
            this.radMon.AutoSize = true;
            this.radMon.Location = new System.Drawing.Point(6, 14);
            this.radMon.Name = "radMon";
            this.radMon.Size = new System.Drawing.Size(89, 24);
            this.radMon.TabIndex = 0;
            this.radMon.TabStop = true;
            this.radMon.Text = "Monday";
            this.radMon.UseVisualStyleBackColor = true;
            this.radMon.CheckedChanged += new System.EventHandler(this.radMon_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.GrayText;
            this.groupBox4.Controls.Add(this.hoursLabel10);
            this.groupBox4.Controls.Add(this.hoursLabel9);
            this.groupBox4.Controls.Add(this.hoursLabel8);
            this.groupBox4.Controls.Add(this.hoursLabel7);
            this.groupBox4.Controls.Add(this.hoursLabel6);
            this.groupBox4.Controls.Add(this.hoursLabel5);
            this.groupBox4.Controls.Add(this.hoursLabel4);
            this.groupBox4.Controls.Add(this.hoursLabel3);
            this.groupBox4.Controls.Add(this.hoursLabel2);
            this.groupBox4.Controls.Add(this.hoursLabel1);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox4.Location = new System.Drawing.Point(647, 79);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(95, 478);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Hrs Worked";
            // 
            // hoursLabel10
            // 
            this.hoursLabel10.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.hoursLabel10.Location = new System.Drawing.Point(16, 429);
            this.hoursLabel10.Name = "hoursLabel10";
            this.hoursLabel10.Size = new System.Drawing.Size(64, 26);
            this.hoursLabel10.TabIndex = 9;
            this.hoursLabel10.Text = "0";
            this.hoursLabel10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // hoursLabel9
            // 
            this.hoursLabel9.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.hoursLabel9.Location = new System.Drawing.Point(16, 387);
            this.hoursLabel9.Name = "hoursLabel9";
            this.hoursLabel9.Size = new System.Drawing.Size(64, 26);
            this.hoursLabel9.TabIndex = 8;
            this.hoursLabel9.Text = "0";
            this.hoursLabel9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // hoursLabel8
            // 
            this.hoursLabel8.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.hoursLabel8.Location = new System.Drawing.Point(16, 341);
            this.hoursLabel8.Name = "hoursLabel8";
            this.hoursLabel8.Size = new System.Drawing.Size(64, 26);
            this.hoursLabel8.TabIndex = 7;
            this.hoursLabel8.Text = "0";
            this.hoursLabel8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // hoursLabel7
            // 
            this.hoursLabel7.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.hoursLabel7.Location = new System.Drawing.Point(16, 296);
            this.hoursLabel7.Name = "hoursLabel7";
            this.hoursLabel7.Size = new System.Drawing.Size(64, 26);
            this.hoursLabel7.TabIndex = 6;
            this.hoursLabel7.Text = "0";
            this.hoursLabel7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // hoursLabel6
            // 
            this.hoursLabel6.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.hoursLabel6.Location = new System.Drawing.Point(16, 251);
            this.hoursLabel6.Name = "hoursLabel6";
            this.hoursLabel6.Size = new System.Drawing.Size(64, 26);
            this.hoursLabel6.TabIndex = 5;
            this.hoursLabel6.Text = "0";
            this.hoursLabel6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // hoursLabel5
            // 
            this.hoursLabel5.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.hoursLabel5.Location = new System.Drawing.Point(16, 205);
            this.hoursLabel5.Name = "hoursLabel5";
            this.hoursLabel5.Size = new System.Drawing.Size(64, 26);
            this.hoursLabel5.TabIndex = 4;
            this.hoursLabel5.Text = "0";
            this.hoursLabel5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // hoursLabel4
            // 
            this.hoursLabel4.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.hoursLabel4.Location = new System.Drawing.Point(16, 164);
            this.hoursLabel4.Name = "hoursLabel4";
            this.hoursLabel4.Size = new System.Drawing.Size(64, 26);
            this.hoursLabel4.TabIndex = 3;
            this.hoursLabel4.Text = "0";
            this.hoursLabel4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // hoursLabel3
            // 
            this.hoursLabel3.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.hoursLabel3.Location = new System.Drawing.Point(16, 121);
            this.hoursLabel3.Name = "hoursLabel3";
            this.hoursLabel3.Size = new System.Drawing.Size(64, 26);
            this.hoursLabel3.TabIndex = 2;
            this.hoursLabel3.Text = "0";
            this.hoursLabel3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // hoursLabel2
            // 
            this.hoursLabel2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.hoursLabel2.Location = new System.Drawing.Point(16, 81);
            this.hoursLabel2.Name = "hoursLabel2";
            this.hoursLabel2.Size = new System.Drawing.Size(64, 26);
            this.hoursLabel2.TabIndex = 1;
            this.hoursLabel2.Text = "0";
            this.hoursLabel2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // hoursLabel1
            // 
            this.hoursLabel1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.hoursLabel1.Location = new System.Drawing.Point(16, 40);
            this.hoursLabel1.Name = "hoursLabel1";
            this.hoursLabel1.Size = new System.Drawing.Size(64, 26);
            this.hoursLabel1.TabIndex = 0;
            this.hoursLabel1.Text = "0";
            this.hoursLabel1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.SystemColors.GrayText;
            this.groupBox5.Controls.Add(this.rate1);
            this.groupBox5.Controls.Add(this.rate10);
            this.groupBox5.Controls.Add(this.rate9);
            this.groupBox5.Controls.Add(this.rate8);
            this.groupBox5.Controls.Add(this.rate7);
            this.groupBox5.Controls.Add(this.rate6);
            this.groupBox5.Controls.Add(this.rate5);
            this.groupBox5.Controls.Add(this.rate4);
            this.groupBox5.Controls.Add(this.rate3);
            this.groupBox5.Controls.Add(this.rate2);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox5.Location = new System.Drawing.Point(449, 79);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(94, 478);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Rate";
            // 
            // rate1
            // 
            this.rate1.FormattingEnabled = true;
            this.rate1.Location = new System.Drawing.Point(15, 38);
            this.rate1.Name = "rate1";
            this.rate1.Size = new System.Drawing.Size(62, 28);
            this.rate1.TabIndex = 2;
            this.rate1.Text = "0";
            this.rate1.SelectedIndexChanged += new System.EventHandler(this.rate1_SelectedIndexChanged);
            // 
            // rate10
            // 
            this.rate10.FormattingEnabled = true;
            this.rate10.Location = new System.Drawing.Point(15, 429);
            this.rate10.Name = "rate10";
            this.rate10.Size = new System.Drawing.Size(62, 28);
            this.rate10.TabIndex = 1;
            this.rate10.Text = "0";
            // 
            // rate9
            // 
            this.rate9.FormattingEnabled = true;
            this.rate9.Location = new System.Drawing.Point(15, 385);
            this.rate9.Name = "rate9";
            this.rate9.Size = new System.Drawing.Size(62, 28);
            this.rate9.TabIndex = 1;
            this.rate9.Text = "0";
            // 
            // rate8
            // 
            this.rate8.FormattingEnabled = true;
            this.rate8.Location = new System.Drawing.Point(15, 339);
            this.rate8.Name = "rate8";
            this.rate8.Size = new System.Drawing.Size(62, 28);
            this.rate8.TabIndex = 1;
            this.rate8.Text = "0";
            // 
            // rate7
            // 
            this.rate7.FormattingEnabled = true;
            this.rate7.Location = new System.Drawing.Point(15, 294);
            this.rate7.Name = "rate7";
            this.rate7.Size = new System.Drawing.Size(62, 28);
            this.rate7.TabIndex = 1;
            this.rate7.Text = "0";
            // 
            // rate6
            // 
            this.rate6.FormattingEnabled = true;
            this.rate6.Location = new System.Drawing.Point(15, 249);
            this.rate6.Name = "rate6";
            this.rate6.Size = new System.Drawing.Size(62, 28);
            this.rate6.TabIndex = 1;
            this.rate6.Text = "0";
            // 
            // rate5
            // 
            this.rate5.FormattingEnabled = true;
            this.rate5.Location = new System.Drawing.Point(15, 207);
            this.rate5.Name = "rate5";
            this.rate5.Size = new System.Drawing.Size(62, 28);
            this.rate5.TabIndex = 1;
            this.rate5.Text = "0";
            // 
            // rate4
            // 
            this.rate4.FormattingEnabled = true;
            this.rate4.Location = new System.Drawing.Point(15, 164);
            this.rate4.Name = "rate4";
            this.rate4.Size = new System.Drawing.Size(62, 28);
            this.rate4.TabIndex = 1;
            this.rate4.Text = "0";
            // 
            // rate3
            // 
            this.rate3.FormattingEnabled = true;
            this.rate3.Location = new System.Drawing.Point(15, 123);
            this.rate3.Name = "rate3";
            this.rate3.Size = new System.Drawing.Size(62, 28);
            this.rate3.TabIndex = 1;
            this.rate3.Text = "0";
            // 
            // rate2
            // 
            this.rate2.FormattingEnabled = true;
            this.rate2.Location = new System.Drawing.Point(15, 79);
            this.rate2.Name = "rate2";
            this.rate2.Size = new System.Drawing.Size(62, 28);
            this.rate2.TabIndex = 1;
            this.rate2.Text = "0";
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.SystemColors.GrayText;
            this.groupBox6.Controls.Add(this.ot7);
            this.groupBox6.Controls.Add(this.ot10);
            this.groupBox6.Controls.Add(this.ot9);
            this.groupBox6.Controls.Add(this.ot8);
            this.groupBox6.Controls.Add(this.ot6);
            this.groupBox6.Controls.Add(this.ot5);
            this.groupBox6.Controls.Add(this.ot4);
            this.groupBox6.Controls.Add(this.ot3);
            this.groupBox6.Controls.Add(this.ot2);
            this.groupBox6.Controls.Add(this.ot1);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox6.Location = new System.Drawing.Point(549, 79);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(92, 478);
            this.groupBox6.TabIndex = 5;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "O.T.";
            // 
            // ot7
            // 
            this.ot7.FormattingEnabled = true;
            this.ot7.Location = new System.Drawing.Point(15, 294);
            this.ot7.Name = "ot7";
            this.ot7.Size = new System.Drawing.Size(62, 28);
            this.ot7.TabIndex = 12;
            this.ot7.Text = "0";
            // 
            // ot10
            // 
            this.ot10.FormattingEnabled = true;
            this.ot10.Location = new System.Drawing.Point(15, 429);
            this.ot10.Name = "ot10";
            this.ot10.Size = new System.Drawing.Size(62, 28);
            this.ot10.TabIndex = 3;
            this.ot10.Text = "0";
            // 
            // ot9
            // 
            this.ot9.FormattingEnabled = true;
            this.ot9.Location = new System.Drawing.Point(15, 385);
            this.ot9.Name = "ot9";
            this.ot9.Size = new System.Drawing.Size(62, 28);
            this.ot9.TabIndex = 4;
            this.ot9.Text = "0";
            // 
            // ot8
            // 
            this.ot8.FormattingEnabled = true;
            this.ot8.Location = new System.Drawing.Point(15, 339);
            this.ot8.Name = "ot8";
            this.ot8.Size = new System.Drawing.Size(62, 28);
            this.ot8.TabIndex = 5;
            this.ot8.Text = "0";
            // 
            // ot6
            // 
            this.ot6.FormattingEnabled = true;
            this.ot6.Location = new System.Drawing.Point(15, 249);
            this.ot6.Name = "ot6";
            this.ot6.Size = new System.Drawing.Size(62, 28);
            this.ot6.TabIndex = 7;
            this.ot6.Text = "0";
            // 
            // ot5
            // 
            this.ot5.FormattingEnabled = true;
            this.ot5.Location = new System.Drawing.Point(15, 205);
            this.ot5.Name = "ot5";
            this.ot5.Size = new System.Drawing.Size(62, 28);
            this.ot5.TabIndex = 8;
            this.ot5.Text = "0";
            // 
            // ot4
            // 
            this.ot4.FormattingEnabled = true;
            this.ot4.Location = new System.Drawing.Point(15, 162);
            this.ot4.Name = "ot4";
            this.ot4.Size = new System.Drawing.Size(62, 28);
            this.ot4.TabIndex = 9;
            this.ot4.Text = "0";
            // 
            // ot3
            // 
            this.ot3.FormattingEnabled = true;
            this.ot3.Location = new System.Drawing.Point(15, 121);
            this.ot3.Name = "ot3";
            this.ot3.Size = new System.Drawing.Size(62, 28);
            this.ot3.TabIndex = 10;
            this.ot3.Text = "0";
            // 
            // ot2
            // 
            this.ot2.FormattingEnabled = true;
            this.ot2.Location = new System.Drawing.Point(15, 79);
            this.ot2.Name = "ot2";
            this.ot2.Size = new System.Drawing.Size(62, 28);
            this.ot2.TabIndex = 11;
            this.ot2.Text = "0";
            // 
            // ot1
            // 
            this.ot1.FormattingEnabled = true;
            this.ot1.Location = new System.Drawing.Point(15, 38);
            this.ot1.Name = "ot1";
            this.ot1.Size = new System.Drawing.Size(62, 28);
            this.ot1.TabIndex = 2;
            this.ot1.Text = "0";
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.SystemColors.GrayText;
            this.groupBox7.Controls.Add(this.label10);
            this.groupBox7.Controls.Add(this.label9);
            this.groupBox7.Controls.Add(this.label8);
            this.groupBox7.Controls.Add(this.label7);
            this.groupBox7.Controls.Add(this.label6);
            this.groupBox7.Controls.Add(this.label5);
            this.groupBox7.Controls.Add(this.label4);
            this.groupBox7.Controls.Add(this.label3);
            this.groupBox7.Controls.Add(this.label2);
            this.groupBox7.Controls.Add(this.label1);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox7.Location = new System.Drawing.Point(1, 79);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(151, 478);
            this.groupBox7.TabIndex = 6;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Employee";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(24, 432);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 20);
            this.label10.TabIndex = 9;
            this.label10.Text = "J. Mulaney";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(24, 388);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 20);
            this.label9.TabIndex = 8;
            this.label9.Text = "B. Burr";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 344);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 20);
            this.label8.TabIndex = 7;
            this.label8.Text = "D. Tosh";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(24, 299);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(112, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "D. Chappelle";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 254);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "R. Cheng";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 210);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "D.Spade";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 165);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "R.Dangerfield";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 126);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "R.Pryor";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "J.Koy";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "M.Birbiglia";
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.SystemColors.GrayText;
            this.groupBox8.Controls.Add(this.timeIn1);
            this.groupBox8.Controls.Add(this.timeIn10);
            this.groupBox8.Controls.Add(this.timeIn9);
            this.groupBox8.Controls.Add(this.timeIn8);
            this.groupBox8.Controls.Add(this.timeIn7);
            this.groupBox8.Controls.Add(this.timeIn6);
            this.groupBox8.Controls.Add(this.timeIn5);
            this.groupBox8.Controls.Add(this.timeIn4);
            this.groupBox8.Controls.Add(this.timeIn3);
            this.groupBox8.Controls.Add(this.timeIn2);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox8.Location = new System.Drawing.Point(158, 79);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(143, 478);
            this.groupBox8.TabIndex = 7;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Time In";
            // 
            // timeIn1
            // 
            this.timeIn1.BackColor = System.Drawing.SystemColors.Window;
            this.timeIn1.Location = new System.Drawing.Point(31, 36);
            this.timeIn1.Name = "timeIn1";
            this.timeIn1.Size = new System.Drawing.Size(82, 26);
            this.timeIn1.TabIndex = 6;
            this.timeIn1.Text = "0";
            this.timeIn1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timeIn10
            // 
            this.timeIn10.BackColor = System.Drawing.SystemColors.Window;
            this.timeIn10.Location = new System.Drawing.Point(31, 431);
            this.timeIn10.Name = "timeIn10";
            this.timeIn10.Size = new System.Drawing.Size(82, 26);
            this.timeIn10.TabIndex = 7;
            this.timeIn10.Text = "0";
            this.timeIn10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timeIn9
            // 
            this.timeIn9.BackColor = System.Drawing.SystemColors.Window;
            this.timeIn9.Location = new System.Drawing.Point(31, 387);
            this.timeIn9.Name = "timeIn9";
            this.timeIn9.Size = new System.Drawing.Size(82, 26);
            this.timeIn9.TabIndex = 8;
            this.timeIn9.Text = "0";
            this.timeIn9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timeIn8
            // 
            this.timeIn8.BackColor = System.Drawing.SystemColors.Window;
            this.timeIn8.Location = new System.Drawing.Point(31, 339);
            this.timeIn8.Name = "timeIn8";
            this.timeIn8.Size = new System.Drawing.Size(82, 26);
            this.timeIn8.TabIndex = 9;
            this.timeIn8.Text = "0";
            this.timeIn8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timeIn7
            // 
            this.timeIn7.BackColor = System.Drawing.SystemColors.Window;
            this.timeIn7.Location = new System.Drawing.Point(31, 296);
            this.timeIn7.Name = "timeIn7";
            this.timeIn7.Size = new System.Drawing.Size(82, 26);
            this.timeIn7.TabIndex = 10;
            this.timeIn7.Text = "0";
            this.timeIn7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timeIn6
            // 
            this.timeIn6.BackColor = System.Drawing.SystemColors.Window;
            this.timeIn6.Location = new System.Drawing.Point(31, 251);
            this.timeIn6.Name = "timeIn6";
            this.timeIn6.Size = new System.Drawing.Size(82, 26);
            this.timeIn6.TabIndex = 15;
            this.timeIn6.Text = "0";
            this.timeIn6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timeIn5
            // 
            this.timeIn5.BackColor = System.Drawing.SystemColors.Window;
            this.timeIn5.Location = new System.Drawing.Point(31, 207);
            this.timeIn5.Name = "timeIn5";
            this.timeIn5.Size = new System.Drawing.Size(82, 26);
            this.timeIn5.TabIndex = 14;
            this.timeIn5.Text = "0";
            this.timeIn5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timeIn4
            // 
            this.timeIn4.BackColor = System.Drawing.SystemColors.Window;
            this.timeIn4.Location = new System.Drawing.Point(30, 162);
            this.timeIn4.Name = "timeIn4";
            this.timeIn4.Size = new System.Drawing.Size(82, 26);
            this.timeIn4.TabIndex = 13;
            this.timeIn4.Text = "0";
            this.timeIn4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timeIn3
            // 
            this.timeIn3.BackColor = System.Drawing.SystemColors.Window;
            this.timeIn3.Location = new System.Drawing.Point(30, 121);
            this.timeIn3.Name = "timeIn3";
            this.timeIn3.Size = new System.Drawing.Size(82, 26);
            this.timeIn3.TabIndex = 12;
            this.timeIn3.Text = "0";
            this.timeIn3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timeIn2
            // 
            this.timeIn2.BackColor = System.Drawing.SystemColors.Window;
            this.timeIn2.Location = new System.Drawing.Point(31, 81);
            this.timeIn2.Name = "timeIn2";
            this.timeIn2.Size = new System.Drawing.Size(82, 26);
            this.timeIn2.TabIndex = 11;
            this.timeIn2.Text = "0";
            this.timeIn2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox9
            // 
            this.groupBox9.BackColor = System.Drawing.SystemColors.GrayText;
            this.groupBox9.Controls.Add(this.timeOut1);
            this.groupBox9.Controls.Add(this.timeOut10);
            this.groupBox9.Controls.Add(this.timeOut9);
            this.groupBox9.Controls.Add(this.timeOut8);
            this.groupBox9.Controls.Add(this.timeOut7);
            this.groupBox9.Controls.Add(this.timeOut6);
            this.groupBox9.Controls.Add(this.timeOut5);
            this.groupBox9.Controls.Add(this.timeOut4);
            this.groupBox9.Controls.Add(this.timeOut3);
            this.groupBox9.Controls.Add(this.timeOut2);
            this.groupBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox9.Location = new System.Drawing.Point(307, 79);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(136, 478);
            this.groupBox9.TabIndex = 8;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Time Out";
            // 
            // timeOut1
            // 
            this.timeOut1.BackColor = System.Drawing.SystemColors.Window;
            this.timeOut1.Location = new System.Drawing.Point(28, 38);
            this.timeOut1.Name = "timeOut1";
            this.timeOut1.Size = new System.Drawing.Size(82, 26);
            this.timeOut1.TabIndex = 6;
            this.timeOut1.Text = "0";
            this.timeOut1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timeOut10
            // 
            this.timeOut10.BackColor = System.Drawing.SystemColors.Window;
            this.timeOut10.Location = new System.Drawing.Point(28, 431);
            this.timeOut10.Name = "timeOut10";
            this.timeOut10.Size = new System.Drawing.Size(82, 26);
            this.timeOut10.TabIndex = 7;
            this.timeOut10.Text = "0";
            this.timeOut10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timeOut9
            // 
            this.timeOut9.BackColor = System.Drawing.SystemColors.Window;
            this.timeOut9.Location = new System.Drawing.Point(28, 387);
            this.timeOut9.Name = "timeOut9";
            this.timeOut9.Size = new System.Drawing.Size(82, 26);
            this.timeOut9.TabIndex = 8;
            this.timeOut9.Text = "0";
            this.timeOut9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timeOut8
            // 
            this.timeOut8.BackColor = System.Drawing.SystemColors.Window;
            this.timeOut8.Location = new System.Drawing.Point(28, 341);
            this.timeOut8.Name = "timeOut8";
            this.timeOut8.Size = new System.Drawing.Size(82, 26);
            this.timeOut8.TabIndex = 9;
            this.timeOut8.Text = "0";
            this.timeOut8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timeOut7
            // 
            this.timeOut7.BackColor = System.Drawing.SystemColors.Window;
            this.timeOut7.Location = new System.Drawing.Point(28, 296);
            this.timeOut7.Name = "timeOut7";
            this.timeOut7.Size = new System.Drawing.Size(82, 26);
            this.timeOut7.TabIndex = 10;
            this.timeOut7.Text = "0";
            this.timeOut7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timeOut6
            // 
            this.timeOut6.BackColor = System.Drawing.SystemColors.Window;
            this.timeOut6.Location = new System.Drawing.Point(28, 251);
            this.timeOut6.Name = "timeOut6";
            this.timeOut6.Size = new System.Drawing.Size(82, 26);
            this.timeOut6.TabIndex = 15;
            this.timeOut6.Text = "0";
            this.timeOut6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timeOut5
            // 
            this.timeOut5.BackColor = System.Drawing.SystemColors.Window;
            this.timeOut5.Location = new System.Drawing.Point(28, 207);
            this.timeOut5.Name = "timeOut5";
            this.timeOut5.Size = new System.Drawing.Size(82, 26);
            this.timeOut5.TabIndex = 14;
            this.timeOut5.Text = "0";
            this.timeOut5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timeOut4
            // 
            this.timeOut4.BackColor = System.Drawing.SystemColors.Window;
            this.timeOut4.Location = new System.Drawing.Point(28, 162);
            this.timeOut4.Name = "timeOut4";
            this.timeOut4.Size = new System.Drawing.Size(82, 26);
            this.timeOut4.TabIndex = 13;
            this.timeOut4.Text = "0";
            this.timeOut4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timeOut3
            // 
            this.timeOut3.BackColor = System.Drawing.SystemColors.Window;
            this.timeOut3.Location = new System.Drawing.Point(28, 123);
            this.timeOut3.Name = "timeOut3";
            this.timeOut3.Size = new System.Drawing.Size(82, 26);
            this.timeOut3.TabIndex = 12;
            this.timeOut3.Text = "0";
            this.timeOut3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timeOut2
            // 
            this.timeOut2.BackColor = System.Drawing.SystemColors.Window;
            this.timeOut2.Location = new System.Drawing.Point(28, 81);
            this.timeOut2.Name = "timeOut2";
            this.timeOut2.Size = new System.Drawing.Size(82, 26);
            this.timeOut2.TabIndex = 11;
            this.timeOut2.Text = "0";
            this.timeOut2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // radTotalWage
            // 
            this.radTotalWage.AutoSize = true;
            this.radTotalWage.Location = new System.Drawing.Point(477, 14);
            this.radTotalWage.Name = "radTotalWage";
            this.radTotalWage.Size = new System.Drawing.Size(119, 24);
            this.radTotalWage.TabIndex = 66;
            this.radTotalWage.TabStop = true;
            this.radTotalWage.Text = "Wages P/W";
            this.radTotalWage.UseVisualStyleBackColor = true;
            // 
            // resetButton
            // 
            this.resetButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.resetButton.Location = new System.Drawing.Point(548, 25);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(177, 40);
            this.resetButton.TabIndex = 4;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click_1);
            // 
            // exitButton
            // 
            this.exitButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.exitButton.Location = new System.Drawing.Point(772, 25);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(161, 40);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1350, 649);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.ComboBox rate10;
        private System.Windows.Forms.ComboBox rate9;
        private System.Windows.Forms.ComboBox rate8;
        private System.Windows.Forms.ComboBox rate7;
        private System.Windows.Forms.ComboBox rate6;
        private System.Windows.Forms.ComboBox rate5;
        private System.Windows.Forms.ComboBox rate4;
        private System.Windows.Forms.ComboBox rate3;
        private System.Windows.Forms.ComboBox rate2;
        private System.Windows.Forms.ComboBox ot10;
        private System.Windows.Forms.ComboBox ot9;
        private System.Windows.Forms.ComboBox ot8;
        private System.Windows.Forms.ComboBox ot6;
        private System.Windows.Forms.ComboBox ot5;
        private System.Windows.Forms.ComboBox ot4;
        private System.Windows.Forms.ComboBox ot3;
        private System.Windows.Forms.ComboBox ot2;
        private System.Windows.Forms.ComboBox ot1;
        private System.Windows.Forms.TextBox timeIn1;
        private System.Windows.Forms.TextBox timeIn10;
        private System.Windows.Forms.TextBox timeIn9;
        private System.Windows.Forms.TextBox timeIn8;
        private System.Windows.Forms.TextBox timeIn7;
        private System.Windows.Forms.TextBox timeIn6;
        private System.Windows.Forms.TextBox timeIn5;
        private System.Windows.Forms.TextBox timeIn4;
        private System.Windows.Forms.TextBox timeIn3;
        private System.Windows.Forms.TextBox timeIn2;
        private System.Windows.Forms.TextBox timeOut1;
        private System.Windows.Forms.TextBox timeOut10;
        private System.Windows.Forms.TextBox timeOut9;
        private System.Windows.Forms.TextBox timeOut8;
        private System.Windows.Forms.TextBox timeOut7;
        private System.Windows.Forms.TextBox timeOut6;
        private System.Windows.Forms.TextBox timeOut5;
        private System.Windows.Forms.TextBox timeOut4;
        private System.Windows.Forms.TextBox timeOut3;
        private System.Windows.Forms.TextBox timeOut2;
        private System.Windows.Forms.TextBox lblFri10;
        private System.Windows.Forms.TextBox lblFri9;
        private System.Windows.Forms.TextBox lblFri8;
        private System.Windows.Forms.TextBox lblFri7;
        private System.Windows.Forms.TextBox lblFri6;
        private System.Windows.Forms.TextBox lblFri5;
        private System.Windows.Forms.TextBox lblFri4;
        private System.Windows.Forms.TextBox lblFri3;
        private System.Windows.Forms.TextBox lblFri2;
        private System.Windows.Forms.TextBox lblFri1;
        private System.Windows.Forms.TextBox lblThurs10;
        private System.Windows.Forms.TextBox lblThurs9;
        private System.Windows.Forms.TextBox lblThurs8;
        private System.Windows.Forms.TextBox lblThurs7;
        private System.Windows.Forms.TextBox lblThurs6;
        private System.Windows.Forms.TextBox lblThurs5;
        private System.Windows.Forms.TextBox lblThurs4;
        private System.Windows.Forms.TextBox lblThurs3;
        private System.Windows.Forms.TextBox lblThurs2;
        private System.Windows.Forms.TextBox lblThurs1;
        private System.Windows.Forms.TextBox lblWed10;
        private System.Windows.Forms.TextBox lblWed9;
        private System.Windows.Forms.TextBox lblWed8;
        private System.Windows.Forms.TextBox lblWed7;
        private System.Windows.Forms.TextBox lblWed6;
        private System.Windows.Forms.TextBox lblWed5;
        private System.Windows.Forms.TextBox lblWed4;
        private System.Windows.Forms.TextBox lblWed3;
        private System.Windows.Forms.TextBox lblWed2;
        private System.Windows.Forms.TextBox lblWed1;
        private System.Windows.Forms.TextBox lblTues10;
        private System.Windows.Forms.TextBox lblTues9;
        private System.Windows.Forms.TextBox lblTues8;
        private System.Windows.Forms.TextBox lblTues7;
        private System.Windows.Forms.TextBox lblTues6;
        private System.Windows.Forms.TextBox lblTues5;
        private System.Windows.Forms.TextBox lblTues4;
        private System.Windows.Forms.TextBox lblTues3;
        private System.Windows.Forms.TextBox lblTues2;
        private System.Windows.Forms.TextBox lblTues1;
        private System.Windows.Forms.TextBox lblMon10;
        private System.Windows.Forms.TextBox lblMon9;
        private System.Windows.Forms.TextBox lblMon8;
        private System.Windows.Forms.TextBox lblMon7;
        private System.Windows.Forms.TextBox lblMon6;
        private System.Windows.Forms.TextBox lblMon5;
        private System.Windows.Forms.TextBox lblMon4;
        private System.Windows.Forms.TextBox lblMon3;
        private System.Windows.Forms.TextBox lblMon2;
        private System.Windows.Forms.TextBox lblMon1;
        private System.Windows.Forms.RadioButton radFri;
        private System.Windows.Forms.RadioButton radThurs;
        private System.Windows.Forms.RadioButton radWed;
        private System.Windows.Forms.RadioButton radTues;
        private System.Windows.Forms.RadioButton radMon;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox rate1;
        private System.Windows.Forms.TextBox totalPymt10;
        private System.Windows.Forms.TextBox totalPymt9;
        private System.Windows.Forms.TextBox totalPymt8;
        private System.Windows.Forms.TextBox totalPymt7;
        private System.Windows.Forms.TextBox totalPymt6;
        private System.Windows.Forms.TextBox totalPymt5;
        private System.Windows.Forms.TextBox totalPymt4;
        private System.Windows.Forms.TextBox totalPymt3;
        private System.Windows.Forms.TextBox totalPymt2;
        private System.Windows.Forms.TextBox totalPymt1;
        private System.Windows.Forms.TextBox hoursLabel10;
        private System.Windows.Forms.TextBox hoursLabel9;
        private System.Windows.Forms.TextBox hoursLabel8;
        private System.Windows.Forms.TextBox hoursLabel7;
        private System.Windows.Forms.TextBox hoursLabel6;
        private System.Windows.Forms.TextBox hoursLabel5;
        private System.Windows.Forms.TextBox hoursLabel4;
        private System.Windows.Forms.TextBox hoursLabel3;
        private System.Windows.Forms.TextBox hoursLabel2;
        private System.Windows.Forms.TextBox hoursLabel1;
        private System.Windows.Forms.Button totalWageButton;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox ot7;
        private System.Windows.Forms.RadioButton radTotalWage;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button exitButton;
    }
}

