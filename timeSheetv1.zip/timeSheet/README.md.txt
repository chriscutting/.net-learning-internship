Hello!
This is my (almost) working timesheet app. It's about 1400 lines.

Most of it is a repition of the calculations to get folks wages so it's actually not super complicated/spaghet.

It has 10 hypothetical employees, calculates their in/out time.

Takes the in/out calc and multiplies by rate and OT, outputs wages correctly.

Currently only works in military time but that's not the main issue.

The main issue is that it's supposed to perform the same functionality for m/t/w/tr/f and add it for the total wages a week.

It does that, except it comes through as strings. So if the reult for the week is $100(mon) + $80(tues) + $90(fri)

The final output is $1008090 instead of $270.

I translated this entire thing from a visual basic tutorial, so I probably just didn't get how to do a type conversion somewhere.

Any thoughts would be greatly appreciated.
-Chris