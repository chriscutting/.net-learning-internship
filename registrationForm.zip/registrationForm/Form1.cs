﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace registrationForm
{
    public partial class Form1 : Form
    {


        string connectionString = @"Data Source=DESKTOP-NMAO0IT\SQLEXPRESS;Initial Catalog=loginForm;Integrated Security=True";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void submitBtn_Click(object sender, EventArgs e)
        {
            if (userNameField.Text == "" || passwordField.Text == "" || passwordConfirmField.Text == "")
            {
                MessageBox.Show("None of the * fields can be left blank!");
            }
            else if (passwordField.Text!=passwordConfirmField.Text)
            {
                MessageBox.Show("Your passwords must match to continue.");
            }
            else
            {

                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {
                    sqlCon.Open();
                    SqlCommand sqlCmd = new SqlCommand("userADD", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@First_Name", firstNameField.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Last_Name", lastNameField.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Phone", phoneField.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@MailingAddress", address1Field.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Email", EmailField.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@userName", userNameField.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@userPassword", passwordField.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@confirmPassword", passwordConfirmField.Text.Trim());
                    sqlCmd.ExecuteNonQuery();
                    MessageBox.Show("Registration Complete!");
                    Clear();
                }
            }




        }
        void Clear()
        {
            firstNameField.Text = lastNameField.Text = phoneField.Text = address1Field.Text = EmailField.Text = userNameField.Text = passwordField.Text = passwordConfirmField.Text = "";
        }
    }
}
