﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Enable ArrayList()
using System.Collections;

namespace IT232Unit5_cutting
{
    class Program
    {
        static void Main(string[] args)
        {
            //Unit 5 Section 1

            //Make an Arraylist 

            ArrayList produceList = new ArrayList();
            int lineCounter = 1;
            string line;
            //Add some items to that

            produceList.Add("bananas 0.59");
            produceList.Add("grapes 2.99");
            produceList.Add("apples 1.49");
            produceList.Add("pears 1.39");
            produceList.Add("lettuce 0.99");
            produceList.Add("onions 0.79");
            produceList.Add("potatoes 0.59");
            produceList.Add("peaches 1.59");

            //Make a .txt file to move into the program
            //Use a for loop to write things into the .txt file.
            //Make it use a 'verbatim identifier' to get the data

            using (StreamWriter writeFile = new StreamWriter(@"produceList.txt"))
            {

                for (int i = 0; i < produceList.Count; i++)
                {
                    writeFile.WriteLine(produceList[i]);
                }
                writeFile.Close();

            }
            // Make a function that uses a while loop to return all of the lines written
            Console.WriteLine("There are " + FileLineCount("produceList.txt") + " products in the file.");

            // Section 2!

            using (StreamWriter appendFile = new StreamWriter(@"produceList.txt", true))
            {
                appendFile.WriteLine("peppers 0.99");
                appendFile.WriteLine("celery 1.29");
                appendFile.WriteLine("cabbage 0.79");
                appendFile.WriteLine("tomatoes 1.19");
                appendFile.Close();

            }
            //display the number of items
            Console.WriteLine("There are " + FileLineCount("produceList.txt") + " products in the file.");

            Console.WriteLine();

           

            using (StreamReader readFile = new StreamReader(@"produceList.txt", true))
            {
                while ((line = readFile.ReadLine()) != null)
                {
                    produceList.Add(line);
                    Console.WriteLine(lineCounter + ". " + line);
                    lineCounter++;
                }
                readFile.Close();
            }
            Console.WriteLine();
            Console.WriteLine("There are " + produceList.Count + " products in the produceList array");
            Console.ReadLine();
        }
        // Let's make some things exist and get rid of these errors.

        static int FileLineCount(string filename)
        {
            int lineCounter = 0;
            string line;
            using (StreamReader readFile = new StreamReader(filename))
            {
                while ((readFile.ReadLine()) != null)
                {
                    lineCounter++;

                }
                readFile.Close();
            }
            return lineCounter;
        }







    }
}
